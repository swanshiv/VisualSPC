﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class MeasureOctaGage
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Me.components = New System.ComponentModel.Container
        Me.TabControl1 = New System.Windows.Forms.TabControl
        Me.TabPage1 = New System.Windows.Forms.TabPage
        Me.Panel8 = New System.Windows.Forms.Panel
        Me.Label52 = New System.Windows.Forms.Label
        Me.Label56 = New System.Windows.Forms.Label
        Me.DataGridView1 = New System.Windows.Forms.DataGridView
        Me.Column1 = New System.Windows.Forms.DataGridViewTextBoxColumn
        Me.Column2 = New System.Windows.Forms.DataGridViewTextBoxColumn
        Me.Column3 = New System.Windows.Forms.DataGridViewTextBoxColumn
        Me.Column4 = New System.Windows.Forms.DataGridViewTextBoxColumn
        Me.Column5 = New System.Windows.Forms.DataGridViewTextBoxColumn
        Me.Column6 = New System.Windows.Forms.DataGridViewTextBoxColumn
        Me.Column7 = New System.Windows.Forms.DataGridViewTextBoxColumn
        Me.Column8 = New System.Windows.Forms.DataGridViewTextBoxColumn
        Me.Column9 = New System.Windows.Forms.DataGridViewTextBoxColumn
        Me.Column10 = New System.Windows.Forms.DataGridViewTextBoxColumn
        Me.Panel2 = New System.Windows.Forms.Panel
        Me.Label17 = New System.Windows.Forms.Label
        Me.Label21 = New System.Windows.Forms.Label
        Me.Panel7 = New System.Windows.Forms.Panel
        Me.Label45 = New System.Windows.Forms.Label
        Me.Label49 = New System.Windows.Forms.Label
        Me.Panel4 = New System.Windows.Forms.Panel
        Me.Label31 = New System.Windows.Forms.Label
        Me.Label35 = New System.Windows.Forms.Label
        Me.Panel9 = New System.Windows.Forms.Panel
        Me.btnResetCounter = New System.Windows.Forms.Button
        Me.lblCounter = New System.Windows.Forms.Label
        Me.Label12 = New System.Windows.Forms.Label
        Me.Label6 = New System.Windows.Forms.Label
        Me.Label7 = New System.Windows.Forms.Label
        Me.Label8 = New System.Windows.Forms.Label
        Me.Label9 = New System.Windows.Forms.Label
        Me.cmbPart = New System.Windows.Forms.ComboBox
        Me.OctaGageBindingSource = New System.Windows.Forms.BindingSource(Me.components)
        Me.VersaGageMonitorDataSet = New VersaGageMonitor.VersaGageMonitorDataSet
        Me.Label2 = New System.Windows.Forms.Label
        Me.Button1 = New System.Windows.Forms.Button
        Me.btnSelectFile = New System.Windows.Forms.Button
        Me.btnStart = New System.Windows.Forms.Button
        Me.Panel5 = New System.Windows.Forms.Panel
        Me.Label5 = New System.Windows.Forms.Label
        Me.Label1 = New System.Windows.Forms.Label
        Me.Panel1 = New System.Windows.Forms.Panel
        Me.Label10 = New System.Windows.Forms.Label
        Me.Label14 = New System.Windows.Forms.Label
        Me.Panel6 = New System.Windows.Forms.Panel
        Me.Label38 = New System.Windows.Forms.Label
        Me.Label42 = New System.Windows.Forms.Label
        Me.Panel3 = New System.Windows.Forms.Panel
        Me.Label24 = New System.Windows.Forms.Label
        Me.Label28 = New System.Windows.Forms.Label
        Me.TabPage4 = New System.Windows.Forms.TabPage
        Me.TableLayoutPanel4 = New System.Windows.Forms.TableLayoutPanel
        Me.Panel20 = New System.Windows.Forms.Panel
        Me.Label153 = New System.Windows.Forms.Label
        Me.Label156 = New System.Windows.Forms.Label
        Me.Label157 = New System.Windows.Forms.Label
        Me.Label161 = New System.Windows.Forms.Label
        Me.Label162 = New System.Windows.Forms.Label
        Me.Label152 = New System.Windows.Forms.Label
        Me.Label154 = New System.Windows.Forms.Label
        Me.Label155 = New System.Windows.Forms.Label
        Me.Label158 = New System.Windows.Forms.Label
        Me.Label159 = New System.Windows.Forms.Label
        Me.Label163 = New System.Windows.Forms.Label
        Me.Label164 = New System.Windows.Forms.Label
        Me.RunChart4 = New VersaGageMonitor.RunChart
        Me.Panel19 = New System.Windows.Forms.Panel
        Me.Label140 = New System.Windows.Forms.Label
        Me.Label143 = New System.Windows.Forms.Label
        Me.Label144 = New System.Windows.Forms.Label
        Me.Label148 = New System.Windows.Forms.Label
        Me.Label149 = New System.Windows.Forms.Label
        Me.Label139 = New System.Windows.Forms.Label
        Me.Label141 = New System.Windows.Forms.Label
        Me.Label142 = New System.Windows.Forms.Label
        Me.Label145 = New System.Windows.Forms.Label
        Me.Label146 = New System.Windows.Forms.Label
        Me.Label150 = New System.Windows.Forms.Label
        Me.Label151 = New System.Windows.Forms.Label
        Me.RunChart3 = New VersaGageMonitor.RunChart
        Me.Panel18 = New System.Windows.Forms.Panel
        Me.Label127 = New System.Windows.Forms.Label
        Me.Label130 = New System.Windows.Forms.Label
        Me.Label131 = New System.Windows.Forms.Label
        Me.Label135 = New System.Windows.Forms.Label
        Me.Label136 = New System.Windows.Forms.Label
        Me.Label126 = New System.Windows.Forms.Label
        Me.Label128 = New System.Windows.Forms.Label
        Me.Label129 = New System.Windows.Forms.Label
        Me.Label132 = New System.Windows.Forms.Label
        Me.Label133 = New System.Windows.Forms.Label
        Me.Label137 = New System.Windows.Forms.Label
        Me.Label138 = New System.Windows.Forms.Label
        Me.RunChart2 = New VersaGageMonitor.RunChart
        Me.Panel17 = New System.Windows.Forms.Panel
        Me.Label124 = New System.Windows.Forms.Label
        Me.Label125 = New System.Windows.Forms.Label
        Me.Label120 = New System.Windows.Forms.Label
        Me.Label121 = New System.Windows.Forms.Label
        Me.Label122 = New System.Windows.Forms.Label
        Me.Label123 = New System.Windows.Forms.Label
        Me.Label114 = New System.Windows.Forms.Label
        Me.Label115 = New System.Windows.Forms.Label
        Me.Label117 = New System.Windows.Forms.Label
        Me.Label118 = New System.Windows.Forms.Label
        Me.Label119 = New System.Windows.Forms.Label
        Me.Label105 = New System.Windows.Forms.Label
        Me.RunChart1 = New VersaGageMonitor.RunChart
        Me.TabPage5 = New System.Windows.Forms.TabPage
        Me.TableLayoutPanel6 = New System.Windows.Forms.TableLayoutPanel
        Me.Panel25 = New System.Windows.Forms.Panel
        Me.Label257 = New System.Windows.Forms.Label
        Me.Label260 = New System.Windows.Forms.Label
        Me.Label261 = New System.Windows.Forms.Label
        Me.Label265 = New System.Windows.Forms.Label
        Me.Label266 = New System.Windows.Forms.Label
        Me.Label217 = New System.Windows.Forms.Label
        Me.Label219 = New System.Windows.Forms.Label
        Me.Label220 = New System.Windows.Forms.Label
        Me.Label223 = New System.Windows.Forms.Label
        Me.Label224 = New System.Windows.Forms.Label
        Me.Label228 = New System.Windows.Forms.Label
        Me.Label229 = New System.Windows.Forms.Label
        Me.RunChart9 = New VersaGageMonitor.RunChart
        Me.Panel26 = New System.Windows.Forms.Panel
        Me.Label244 = New System.Windows.Forms.Label
        Me.Label247 = New System.Windows.Forms.Label
        Me.Label248 = New System.Windows.Forms.Label
        Me.Label252 = New System.Windows.Forms.Label
        Me.Label253 = New System.Windows.Forms.Label
        Me.Label230 = New System.Windows.Forms.Label
        Me.Label232 = New System.Windows.Forms.Label
        Me.Label233 = New System.Windows.Forms.Label
        Me.Label236 = New System.Windows.Forms.Label
        Me.Label237 = New System.Windows.Forms.Label
        Me.Label241 = New System.Windows.Forms.Label
        Me.Label242 = New System.Windows.Forms.Label
        Me.RunChart10 = New VersaGageMonitor.RunChart
        Me.Panel27 = New System.Windows.Forms.Panel
        Me.Label231 = New System.Windows.Forms.Label
        Me.Label234 = New System.Windows.Forms.Label
        Me.Label235 = New System.Windows.Forms.Label
        Me.Label239 = New System.Windows.Forms.Label
        Me.Label240 = New System.Windows.Forms.Label
        Me.Label243 = New System.Windows.Forms.Label
        Me.Label245 = New System.Windows.Forms.Label
        Me.Label246 = New System.Windows.Forms.Label
        Me.Label249 = New System.Windows.Forms.Label
        Me.Label250 = New System.Windows.Forms.Label
        Me.Label254 = New System.Windows.Forms.Label
        Me.Label255 = New System.Windows.Forms.Label
        Me.RunChart11 = New VersaGageMonitor.RunChart
        Me.Panel28 = New System.Windows.Forms.Panel
        Me.Label218 = New System.Windows.Forms.Label
        Me.Label221 = New System.Windows.Forms.Label
        Me.Label222 = New System.Windows.Forms.Label
        Me.Label226 = New System.Windows.Forms.Label
        Me.Label227 = New System.Windows.Forms.Label
        Me.Label256 = New System.Windows.Forms.Label
        Me.Label258 = New System.Windows.Forms.Label
        Me.Label259 = New System.Windows.Forms.Label
        Me.Label262 = New System.Windows.Forms.Label
        Me.Label263 = New System.Windows.Forms.Label
        Me.Label267 = New System.Windows.Forms.Label
        Me.Label268 = New System.Windows.Forms.Label
        Me.RunChart12 = New VersaGageMonitor.RunChart
        Me.TableLayoutPanel5 = New System.Windows.Forms.TableLayoutPanel
        Me.Panel21 = New System.Windows.Forms.Panel
        Me.Label165 = New System.Windows.Forms.Label
        Me.Label166 = New System.Windows.Forms.Label
        Me.Label167 = New System.Windows.Forms.Label
        Me.Label168 = New System.Windows.Forms.Label
        Me.Label169 = New System.Windows.Forms.Label
        Me.Label170 = New System.Windows.Forms.Label
        Me.Label171 = New System.Windows.Forms.Label
        Me.Label172 = New System.Windows.Forms.Label
        Me.Label173 = New System.Windows.Forms.Label
        Me.Label174 = New System.Windows.Forms.Label
        Me.Label175 = New System.Windows.Forms.Label
        Me.Label176 = New System.Windows.Forms.Label
        Me.Label177 = New System.Windows.Forms.Label
        Me.Panel22 = New System.Windows.Forms.Panel
        Me.Label178 = New System.Windows.Forms.Label
        Me.Label179 = New System.Windows.Forms.Label
        Me.Label180 = New System.Windows.Forms.Label
        Me.Label181 = New System.Windows.Forms.Label
        Me.Label182 = New System.Windows.Forms.Label
        Me.Label183 = New System.Windows.Forms.Label
        Me.Label184 = New System.Windows.Forms.Label
        Me.Label185 = New System.Windows.Forms.Label
        Me.Label186 = New System.Windows.Forms.Label
        Me.Label187 = New System.Windows.Forms.Label
        Me.Label188 = New System.Windows.Forms.Label
        Me.Label189 = New System.Windows.Forms.Label
        Me.Label190 = New System.Windows.Forms.Label
        Me.Panel23 = New System.Windows.Forms.Panel
        Me.Label191 = New System.Windows.Forms.Label
        Me.Label192 = New System.Windows.Forms.Label
        Me.Label193 = New System.Windows.Forms.Label
        Me.Label194 = New System.Windows.Forms.Label
        Me.Label195 = New System.Windows.Forms.Label
        Me.Label196 = New System.Windows.Forms.Label
        Me.Label197 = New System.Windows.Forms.Label
        Me.Label198 = New System.Windows.Forms.Label
        Me.Label199 = New System.Windows.Forms.Label
        Me.Label200 = New System.Windows.Forms.Label
        Me.Label201 = New System.Windows.Forms.Label
        Me.Label202 = New System.Windows.Forms.Label
        Me.Label203 = New System.Windows.Forms.Label
        Me.Panel24 = New System.Windows.Forms.Panel
        Me.Label204 = New System.Windows.Forms.Label
        Me.Label205 = New System.Windows.Forms.Label
        Me.Label206 = New System.Windows.Forms.Label
        Me.Label207 = New System.Windows.Forms.Label
        Me.Label208 = New System.Windows.Forms.Label
        Me.Label209 = New System.Windows.Forms.Label
        Me.Label210 = New System.Windows.Forms.Label
        Me.Label211 = New System.Windows.Forms.Label
        Me.Label212 = New System.Windows.Forms.Label
        Me.Label213 = New System.Windows.Forms.Label
        Me.Label214 = New System.Windows.Forms.Label
        Me.Label215 = New System.Windows.Forms.Label
        Me.Label216 = New System.Windows.Forms.Label
        Me.TableLayoutPanel2 = New System.Windows.Forms.TableLayoutPanel
        Me.Panel29 = New System.Windows.Forms.Panel
        Me.Label269 = New System.Windows.Forms.Label
        Me.Label270 = New System.Windows.Forms.Label
        Me.Label271 = New System.Windows.Forms.Label
        Me.Label272 = New System.Windows.Forms.Label
        Me.Label273 = New System.Windows.Forms.Label
        Me.Label274 = New System.Windows.Forms.Label
        Me.Label275 = New System.Windows.Forms.Label
        Me.Panel30 = New System.Windows.Forms.Panel
        Me.Label276 = New System.Windows.Forms.Label
        Me.Label277 = New System.Windows.Forms.Label
        Me.Label278 = New System.Windows.Forms.Label
        Me.Label279 = New System.Windows.Forms.Label
        Me.Label280 = New System.Windows.Forms.Label
        Me.Label281 = New System.Windows.Forms.Label
        Me.Label282 = New System.Windows.Forms.Label
        Me.Panel31 = New System.Windows.Forms.Panel
        Me.Label283 = New System.Windows.Forms.Label
        Me.Label284 = New System.Windows.Forms.Label
        Me.Label285 = New System.Windows.Forms.Label
        Me.Label286 = New System.Windows.Forms.Label
        Me.Label287 = New System.Windows.Forms.Label
        Me.Label288 = New System.Windows.Forms.Label
        Me.Label289 = New System.Windows.Forms.Label
        Me.SaveFileDialog1 = New System.Windows.Forms.SaveFileDialog
        Me.OpenFileDialog1 = New System.Windows.Forms.OpenFileDialog
        Me.Timer2 = New System.Windows.Forms.Timer(Me.components)
        Me.Timer3 = New System.Windows.Forms.Timer(Me.components)
        Me.lblReadingSaved = New System.Windows.Forms.Label
        Me.CustomerOctaGageTableAdapter = New VersaGageMonitor.VersaGageMonitorDataSetTableAdapters.CustomerOctaGageTableAdapter
        Me.lblFileSel = New System.Windows.Forms.Label
        Me.TabControl1.SuspendLayout()
        Me.TabPage1.SuspendLayout()
        Me.Panel8.SuspendLayout()
        CType(Me.DataGridView1, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.Panel2.SuspendLayout()
        Me.Panel7.SuspendLayout()
        Me.Panel4.SuspendLayout()
        Me.Panel9.SuspendLayout()
        CType(Me.OctaGageBindingSource, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.VersaGageMonitorDataSet, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.Panel5.SuspendLayout()
        Me.Panel1.SuspendLayout()
        Me.Panel6.SuspendLayout()
        Me.Panel3.SuspendLayout()
        Me.TabPage4.SuspendLayout()
        Me.TableLayoutPanel4.SuspendLayout()
        Me.Panel20.SuspendLayout()
        Me.Panel19.SuspendLayout()
        Me.Panel18.SuspendLayout()
        Me.Panel17.SuspendLayout()
        Me.TabPage5.SuspendLayout()
        Me.TableLayoutPanel6.SuspendLayout()
        Me.Panel25.SuspendLayout()
        Me.Panel26.SuspendLayout()
        Me.Panel27.SuspendLayout()
        Me.Panel28.SuspendLayout()
        Me.TableLayoutPanel5.SuspendLayout()
        Me.Panel21.SuspendLayout()
        Me.Panel22.SuspendLayout()
        Me.Panel23.SuspendLayout()
        Me.Panel24.SuspendLayout()
        Me.TableLayoutPanel2.SuspendLayout()
        Me.Panel29.SuspendLayout()
        Me.Panel30.SuspendLayout()
        Me.Panel31.SuspendLayout()
        Me.SuspendLayout()
        '
        'TabControl1
        '
        Me.TabControl1.Controls.Add(Me.TabPage1)
        Me.TabControl1.Controls.Add(Me.TabPage4)
        Me.TabControl1.Controls.Add(Me.TabPage5)
        Me.TabControl1.Font = New System.Drawing.Font("Arial", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.TabControl1.Location = New System.Drawing.Point(9, 36)
        Me.TabControl1.Name = "TabControl1"
        Me.TabControl1.SelectedIndex = 0
        Me.TabControl1.Size = New System.Drawing.Size(994, 609)
        Me.TabControl1.TabIndex = 1
        '
        'TabPage1
        '
        Me.TabPage1.BackColor = System.Drawing.Color.OldLace
        Me.TabPage1.Controls.Add(Me.Panel8)
        Me.TabPage1.Controls.Add(Me.DataGridView1)
        Me.TabPage1.Controls.Add(Me.Panel2)
        Me.TabPage1.Controls.Add(Me.Panel7)
        Me.TabPage1.Controls.Add(Me.Panel4)
        Me.TabPage1.Controls.Add(Me.Panel9)
        Me.TabPage1.Controls.Add(Me.Panel5)
        Me.TabPage1.Controls.Add(Me.Panel1)
        Me.TabPage1.Controls.Add(Me.Panel6)
        Me.TabPage1.Controls.Add(Me.Panel3)
        Me.TabPage1.Location = New System.Drawing.Point(4, 27)
        Me.TabPage1.Name = "TabPage1"
        Me.TabPage1.Padding = New System.Windows.Forms.Padding(3)
        Me.TabPage1.Size = New System.Drawing.Size(986, 578)
        Me.TabPage1.TabIndex = 0
        Me.TabPage1.Text = "DRO"
        '
        'Panel8
        '
        Me.Panel8.BackColor = System.Drawing.Color.OldLace
        Me.Panel8.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.Panel8.Controls.Add(Me.Label52)
        Me.Panel8.Controls.Add(Me.Label56)
        Me.Panel8.Location = New System.Drawing.Point(467, 226)
        Me.Panel8.Name = "Panel8"
        Me.Panel8.Size = New System.Drawing.Size(221, 64)
        Me.Panel8.TabIndex = 24
        Me.Panel8.Visible = False
        '
        'Label52
        '
        Me.Label52.Font = New System.Drawing.Font("Arial", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label52.Location = New System.Drawing.Point(5, 4)
        Me.Label52.Name = "Label52"
        Me.Label52.Size = New System.Drawing.Size(211, 18)
        Me.Label52.TabIndex = 2
        Me.Label52.Text = "Result 4"
        Me.Label52.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'Label56
        '
        Me.Label56.AutoSize = True
        Me.Label56.BackColor = System.Drawing.Color.LightGray
        Me.Label56.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.Label56.Font = New System.Drawing.Font("Arial", 18.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label56.ForeColor = System.Drawing.Color.Black
        Me.Label56.Location = New System.Drawing.Point(48, 29)
        Me.Label56.Name = "Label56"
        Me.Label56.Size = New System.Drawing.Size(126, 29)
        Me.Label56.TabIndex = 28
        Me.Label56.Text = "+000.0000"
        Me.Label56.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'DataGridView1
        '
        Me.DataGridView1.AllowUserToAddRows = False
        Me.DataGridView1.AllowUserToDeleteRows = False
        Me.DataGridView1.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize
        Me.DataGridView1.Columns.AddRange(New System.Windows.Forms.DataGridViewColumn() {Me.Column1, Me.Column2, Me.Column3, Me.Column4, Me.Column5, Me.Column6, Me.Column7, Me.Column8, Me.Column9, Me.Column10})
        Me.DataGridView1.Location = New System.Drawing.Point(6, 298)
        Me.DataGridView1.MultiSelect = False
        Me.DataGridView1.Name = "DataGridView1"
        Me.DataGridView1.ReadOnly = True
        Me.DataGridView1.RowHeadersVisible = False
        Me.DataGridView1.RowTemplate.DefaultCellStyle.BackColor = System.Drawing.Color.White
        Me.DataGridView1.RowTemplate.DefaultCellStyle.ForeColor = System.Drawing.Color.Black
        Me.DataGridView1.RowTemplate.DefaultCellStyle.SelectionBackColor = System.Drawing.Color.DimGray
        Me.DataGridView1.SelectionMode = System.Windows.Forms.DataGridViewSelectionMode.FullRowSelect
        Me.DataGridView1.Size = New System.Drawing.Size(968, 272)
        Me.DataGridView1.TabIndex = 49
        Me.DataGridView1.Visible = False
        '
        'Column1
        '
        Me.Column1.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.None
        Me.Column1.HeaderText = "Date"
        Me.Column1.Name = "Column1"
        Me.Column1.ReadOnly = True
        Me.Column1.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.NotSortable
        Me.Column1.Width = 75
        '
        'Column2
        '
        Me.Column2.HeaderText = "Time"
        Me.Column2.Name = "Column2"
        Me.Column2.ReadOnly = True
        Me.Column2.Width = 75
        '
        'Column3
        '
        Me.Column3.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.None
        Me.Column3.HeaderText = "R1"
        Me.Column3.Name = "Column3"
        Me.Column3.ReadOnly = True
        Me.Column3.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.NotSortable
        '
        'Column4
        '
        Me.Column4.HeaderText = "R2"
        Me.Column4.Name = "Column4"
        Me.Column4.ReadOnly = True
        '
        'Column5
        '
        Me.Column5.HeaderText = "R3"
        Me.Column5.Name = "Column5"
        Me.Column5.ReadOnly = True
        '
        'Column6
        '
        Me.Column6.HeaderText = "R4"
        Me.Column6.Name = "Column6"
        Me.Column6.ReadOnly = True
        '
        'Column7
        '
        Me.Column7.HeaderText = "R5"
        Me.Column7.Name = "Column7"
        Me.Column7.ReadOnly = True
        '
        'Column8
        '
        Me.Column8.HeaderText = "R6"
        Me.Column8.Name = "Column8"
        Me.Column8.ReadOnly = True
        '
        'Column9
        '
        Me.Column9.HeaderText = "R7"
        Me.Column9.Name = "Column9"
        Me.Column9.ReadOnly = True
        '
        'Column10
        '
        Me.Column10.HeaderText = "R8"
        Me.Column10.Name = "Column10"
        Me.Column10.ReadOnly = True
        '
        'Panel2
        '
        Me.Panel2.BackColor = System.Drawing.Color.OldLace
        Me.Panel2.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.Panel2.Controls.Add(Me.Label17)
        Me.Panel2.Controls.Add(Me.Label21)
        Me.Panel2.Location = New System.Drawing.Point(467, 156)
        Me.Panel2.Name = "Panel2"
        Me.Panel2.Size = New System.Drawing.Size(221, 64)
        Me.Panel2.TabIndex = 19
        Me.Panel2.Visible = False
        '
        'Label17
        '
        Me.Label17.Font = New System.Drawing.Font("Arial", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label17.Location = New System.Drawing.Point(5, 4)
        Me.Label17.Name = "Label17"
        Me.Label17.Size = New System.Drawing.Size(211, 18)
        Me.Label17.TabIndex = 2
        Me.Label17.Text = "Result 3"
        Me.Label17.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'Label21
        '
        Me.Label21.AutoSize = True
        Me.Label21.BackColor = System.Drawing.Color.LightGray
        Me.Label21.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.Label21.Font = New System.Drawing.Font("Arial", 18.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label21.ForeColor = System.Drawing.Color.Black
        Me.Label21.Location = New System.Drawing.Point(48, 29)
        Me.Label21.Name = "Label21"
        Me.Label21.Size = New System.Drawing.Size(126, 29)
        Me.Label21.TabIndex = 28
        Me.Label21.Text = "+000.0000"
        Me.Label21.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'Panel7
        '
        Me.Panel7.BackColor = System.Drawing.Color.OldLace
        Me.Panel7.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.Panel7.Controls.Add(Me.Label45)
        Me.Panel7.Controls.Add(Me.Label49)
        Me.Panel7.Location = New System.Drawing.Point(694, 224)
        Me.Panel7.Name = "Panel7"
        Me.Panel7.Size = New System.Drawing.Size(221, 64)
        Me.Panel7.TabIndex = 23
        Me.Panel7.Visible = False
        '
        'Label45
        '
        Me.Label45.Font = New System.Drawing.Font("Arial", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label45.Location = New System.Drawing.Point(5, 4)
        Me.Label45.Name = "Label45"
        Me.Label45.Size = New System.Drawing.Size(211, 18)
        Me.Label45.TabIndex = 2
        Me.Label45.Text = "Result 8"
        Me.Label45.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'Label49
        '
        Me.Label49.AutoSize = True
        Me.Label49.BackColor = System.Drawing.Color.LightGray
        Me.Label49.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.Label49.Font = New System.Drawing.Font("Arial", 18.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label49.ForeColor = System.Drawing.Color.Black
        Me.Label49.Location = New System.Drawing.Point(48, 29)
        Me.Label49.Name = "Label49"
        Me.Label49.Size = New System.Drawing.Size(126, 29)
        Me.Label49.TabIndex = 28
        Me.Label49.Text = "+000.0000"
        Me.Label49.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'Panel4
        '
        Me.Panel4.BackColor = System.Drawing.Color.OldLace
        Me.Panel4.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.Panel4.Controls.Add(Me.Label31)
        Me.Panel4.Controls.Add(Me.Label35)
        Me.Panel4.Location = New System.Drawing.Point(467, 86)
        Me.Panel4.Name = "Panel4"
        Me.Panel4.Size = New System.Drawing.Size(221, 64)
        Me.Panel4.TabIndex = 21
        Me.Panel4.Visible = False
        '
        'Label31
        '
        Me.Label31.Font = New System.Drawing.Font("Arial", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label31.Location = New System.Drawing.Point(5, 4)
        Me.Label31.Name = "Label31"
        Me.Label31.Size = New System.Drawing.Size(211, 18)
        Me.Label31.TabIndex = 2
        Me.Label31.Text = "Result 2"
        Me.Label31.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'Label35
        '
        Me.Label35.AutoSize = True
        Me.Label35.BackColor = System.Drawing.Color.LightGray
        Me.Label35.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.Label35.Font = New System.Drawing.Font("Arial", 18.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label35.ForeColor = System.Drawing.Color.Black
        Me.Label35.Location = New System.Drawing.Point(48, 29)
        Me.Label35.Name = "Label35"
        Me.Label35.Size = New System.Drawing.Size(126, 29)
        Me.Label35.TabIndex = 28
        Me.Label35.Text = "+000.0000"
        Me.Label35.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'Panel9
        '
        Me.Panel9.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.Panel9.Controls.Add(Me.btnResetCounter)
        Me.Panel9.Controls.Add(Me.lblCounter)
        Me.Panel9.Controls.Add(Me.Label12)
        Me.Panel9.Controls.Add(Me.Label6)
        Me.Panel9.Controls.Add(Me.Label7)
        Me.Panel9.Controls.Add(Me.Label8)
        Me.Panel9.Controls.Add(Me.Label9)
        Me.Panel9.Controls.Add(Me.cmbPart)
        Me.Panel9.Controls.Add(Me.Label2)
        Me.Panel9.Controls.Add(Me.Button1)
        Me.Panel9.Controls.Add(Me.btnSelectFile)
        Me.Panel9.Controls.Add(Me.btnStart)
        Me.Panel9.Location = New System.Drawing.Point(6, 16)
        Me.Panel9.Name = "Panel9"
        Me.Panel9.Size = New System.Drawing.Size(455, 274)
        Me.Panel9.TabIndex = 4
        '
        'btnResetCounter
        '
        Me.btnResetCounter.Font = New System.Drawing.Font("Arial", 11.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.btnResetCounter.ForeColor = System.Drawing.SystemColors.ControlText
        Me.btnResetCounter.Location = New System.Drawing.Point(307, 223)
        Me.btnResetCounter.Name = "btnResetCounter"
        Me.btnResetCounter.Size = New System.Drawing.Size(122, 23)
        Me.btnResetCounter.TabIndex = 95
        Me.btnResetCounter.Text = "Reset Counter"
        Me.btnResetCounter.UseVisualStyleBackColor = True
        '
        'lblCounter
        '
        Me.lblCounter.AutoSize = True
        Me.lblCounter.BackColor = System.Drawing.Color.Transparent
        Me.lblCounter.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.lblCounter.Font = New System.Drawing.Font("Arial", 11.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblCounter.ForeColor = System.Drawing.Color.Black
        Me.lblCounter.Location = New System.Drawing.Point(194, 225)
        Me.lblCounter.Name = "lblCounter"
        Me.lblCounter.Size = New System.Drawing.Size(18, 19)
        Me.lblCounter.TabIndex = 94
        Me.lblCounter.Text = "0"
        '
        'Label12
        '
        Me.Label12.AutoSize = True
        Me.Label12.BackColor = System.Drawing.Color.Transparent
        Me.Label12.Font = New System.Drawing.Font("Arial", 11.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label12.ForeColor = System.Drawing.Color.Black
        Me.Label12.Location = New System.Drawing.Point(9, 225)
        Me.Label12.Name = "Label12"
        Me.Label12.Size = New System.Drawing.Size(177, 17)
        Me.Label12.TabIndex = 93
        Me.Label12.Text = "Reading Storage Counter:"
        '
        'Label6
        '
        Me.Label6.AutoSize = True
        Me.Label6.BackColor = System.Drawing.Color.Transparent
        Me.Label6.Font = New System.Drawing.Font("Arial", 11.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label6.ForeColor = System.Drawing.Color.Black
        Me.Label6.Location = New System.Drawing.Point(184, 131)
        Me.Label6.Name = "Label6"
        Me.Label6.Size = New System.Drawing.Size(13, 17)
        Me.Label6.TabIndex = 90
        Me.Label6.Text = "-"
        '
        'Label7
        '
        Me.Label7.AutoSize = True
        Me.Label7.BackColor = System.Drawing.Color.Transparent
        Me.Label7.Font = New System.Drawing.Font("Arial", 11.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label7.ForeColor = System.Drawing.Color.Black
        Me.Label7.Location = New System.Drawing.Point(183, 166)
        Me.Label7.Name = "Label7"
        Me.Label7.Size = New System.Drawing.Size(13, 17)
        Me.Label7.TabIndex = 89
        Me.Label7.Text = "-"
        '
        'Label8
        '
        Me.Label8.AutoSize = True
        Me.Label8.BackColor = System.Drawing.Color.Transparent
        Me.Label8.Font = New System.Drawing.Font("Arial", 11.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label8.ForeColor = System.Drawing.Color.Black
        Me.Label8.Location = New System.Drawing.Point(9, 169)
        Me.Label8.Name = "Label8"
        Me.Label8.Size = New System.Drawing.Size(143, 17)
        Me.Label8.TabIndex = 88
        Me.Label8.Text = "Parameters Defined:"
        Me.Label8.TextAlign = System.Drawing.ContentAlignment.MiddleLeft
        '
        'Label9
        '
        Me.Label9.AutoSize = True
        Me.Label9.BackColor = System.Drawing.Color.Transparent
        Me.Label9.Font = New System.Drawing.Font("Arial", 11.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label9.ForeColor = System.Drawing.Color.Black
        Me.Label9.Location = New System.Drawing.Point(10, 134)
        Me.Label9.Name = "Label9"
        Me.Label9.Size = New System.Drawing.Size(77, 17)
        Me.Label9.TabIndex = 87
        Me.Label9.Text = "Customer:"
        Me.Label9.TextAlign = System.Drawing.ContentAlignment.MiddleLeft
        '
        'cmbPart
        '
        Me.cmbPart.DataSource = Me.OctaGageBindingSource
        Me.cmbPart.DisplayMember = "PartName"
        Me.cmbPart.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList
        Me.cmbPart.Font = New System.Drawing.Font("Microsoft Sans Serif", 14.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.cmbPart.ForeColor = System.Drawing.Color.Black
        Me.cmbPart.FormattingEnabled = True
        Me.cmbPart.Location = New System.Drawing.Point(156, 9)
        Me.cmbPart.Name = "cmbPart"
        Me.cmbPart.Size = New System.Drawing.Size(278, 32)
        Me.cmbPart.TabIndex = 82
        Me.cmbPart.ValueMember = "partId"
        '
        'OctaGageBindingSource
        '
        Me.OctaGageBindingSource.DataMember = "CustomerOctaGage"
        Me.OctaGageBindingSource.DataSource = Me.VersaGageMonitorDataSet
        '
        'VersaGageMonitorDataSet
        '
        Me.VersaGageMonitorDataSet.DataSetName = "VersaGageMonitorDataSet"
        Me.VersaGageMonitorDataSet.SchemaSerializationMode = System.Data.SchemaSerializationMode.IncludeSchema
        '
        'Label2
        '
        Me.Label2.AutoSize = True
        Me.Label2.BackColor = System.Drawing.Color.Transparent
        Me.Label2.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label2.ForeColor = System.Drawing.Color.Black
        Me.Label2.Location = New System.Drawing.Point(37, 18)
        Me.Label2.Name = "Label2"
        Me.Label2.Size = New System.Drawing.Size(103, 20)
        Me.Label2.TabIndex = 81
        Me.Label2.Text = "Select Part:"
        Me.Label2.TextAlign = System.Drawing.ContentAlignment.MiddleLeft
        '
        'Button1
        '
        Me.Button1.Font = New System.Drawing.Font("Arial", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Button1.Location = New System.Drawing.Point(156, 64)
        Me.Button1.Name = "Button1"
        Me.Button1.Size = New System.Drawing.Size(133, 35)
        Me.Button1.TabIndex = 63
        Me.Button1.Text = "Create Data File"
        Me.Button1.UseVisualStyleBackColor = True
        '
        'btnSelectFile
        '
        Me.btnSelectFile.Font = New System.Drawing.Font("Arial", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.btnSelectFile.Location = New System.Drawing.Point(7, 64)
        Me.btnSelectFile.Name = "btnSelectFile"
        Me.btnSelectFile.Size = New System.Drawing.Size(133, 35)
        Me.btnSelectFile.TabIndex = 62
        Me.btnSelectFile.Text = "Select Data File"
        Me.btnSelectFile.UseVisualStyleBackColor = True
        '
        'btnStart
        '
        Me.btnStart.BackColor = System.Drawing.Color.LimeGreen
        Me.btnStart.Font = New System.Drawing.Font("Arial", 12.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.btnStart.Location = New System.Drawing.Point(301, 63)
        Me.btnStart.Name = "btnStart"
        Me.btnStart.Size = New System.Drawing.Size(133, 35)
        Me.btnStart.TabIndex = 61
        Me.btnStart.Text = "START"
        Me.btnStart.UseVisualStyleBackColor = False
        '
        'Panel5
        '
        Me.Panel5.BackColor = System.Drawing.Color.OldLace
        Me.Panel5.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.Panel5.Controls.Add(Me.Label5)
        Me.Panel5.Controls.Add(Me.Label1)
        Me.Panel5.Location = New System.Drawing.Point(467, 16)
        Me.Panel5.Name = "Panel5"
        Me.Panel5.Size = New System.Drawing.Size(221, 64)
        Me.Panel5.TabIndex = 17
        Me.Panel5.Visible = False
        '
        'Label5
        '
        Me.Label5.Font = New System.Drawing.Font("Arial", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label5.Location = New System.Drawing.Point(5, 4)
        Me.Label5.Name = "Label5"
        Me.Label5.Size = New System.Drawing.Size(211, 18)
        Me.Label5.TabIndex = 2
        Me.Label5.Text = "Result 1"
        Me.Label5.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'Label1
        '
        Me.Label1.AutoSize = True
        Me.Label1.BackColor = System.Drawing.Color.LightGray
        Me.Label1.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.Label1.Font = New System.Drawing.Font("Arial", 18.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label1.ForeColor = System.Drawing.Color.Black
        Me.Label1.Location = New System.Drawing.Point(48, 29)
        Me.Label1.Name = "Label1"
        Me.Label1.Size = New System.Drawing.Size(126, 29)
        Me.Label1.TabIndex = 28
        Me.Label1.Text = "+000.0000"
        Me.Label1.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'Panel1
        '
        Me.Panel1.BackColor = System.Drawing.Color.OldLace
        Me.Panel1.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.Panel1.Controls.Add(Me.Label10)
        Me.Panel1.Controls.Add(Me.Label14)
        Me.Panel1.Location = New System.Drawing.Point(694, 16)
        Me.Panel1.Name = "Panel1"
        Me.Panel1.Size = New System.Drawing.Size(221, 64)
        Me.Panel1.TabIndex = 18
        Me.Panel1.Visible = False
        '
        'Label10
        '
        Me.Label10.Font = New System.Drawing.Font("Arial", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label10.Location = New System.Drawing.Point(5, 4)
        Me.Label10.Name = "Label10"
        Me.Label10.Size = New System.Drawing.Size(211, 18)
        Me.Label10.TabIndex = 2
        Me.Label10.Text = "Result 5"
        Me.Label10.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'Label14
        '
        Me.Label14.AutoSize = True
        Me.Label14.BackColor = System.Drawing.Color.LightGray
        Me.Label14.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.Label14.Font = New System.Drawing.Font("Arial", 18.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label14.ForeColor = System.Drawing.Color.Black
        Me.Label14.Location = New System.Drawing.Point(48, 29)
        Me.Label14.Name = "Label14"
        Me.Label14.Size = New System.Drawing.Size(126, 29)
        Me.Label14.TabIndex = 28
        Me.Label14.Text = "+000.0000"
        Me.Label14.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'Panel6
        '
        Me.Panel6.BackColor = System.Drawing.Color.OldLace
        Me.Panel6.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.Panel6.Controls.Add(Me.Label38)
        Me.Panel6.Controls.Add(Me.Label42)
        Me.Panel6.Location = New System.Drawing.Point(694, 156)
        Me.Panel6.Name = "Panel6"
        Me.Panel6.Size = New System.Drawing.Size(221, 64)
        Me.Panel6.TabIndex = 22
        Me.Panel6.Visible = False
        '
        'Label38
        '
        Me.Label38.Font = New System.Drawing.Font("Arial", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label38.Location = New System.Drawing.Point(5, 4)
        Me.Label38.Name = "Label38"
        Me.Label38.Size = New System.Drawing.Size(211, 18)
        Me.Label38.TabIndex = 2
        Me.Label38.Text = "Result 7"
        Me.Label38.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'Label42
        '
        Me.Label42.AutoSize = True
        Me.Label42.BackColor = System.Drawing.Color.LightGray
        Me.Label42.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.Label42.Font = New System.Drawing.Font("Arial", 18.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label42.ForeColor = System.Drawing.Color.Black
        Me.Label42.Location = New System.Drawing.Point(48, 29)
        Me.Label42.Name = "Label42"
        Me.Label42.Size = New System.Drawing.Size(126, 29)
        Me.Label42.TabIndex = 28
        Me.Label42.Text = "+000.0000"
        Me.Label42.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'Panel3
        '
        Me.Panel3.BackColor = System.Drawing.Color.OldLace
        Me.Panel3.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.Panel3.Controls.Add(Me.Label24)
        Me.Panel3.Controls.Add(Me.Label28)
        Me.Panel3.Location = New System.Drawing.Point(694, 86)
        Me.Panel3.Name = "Panel3"
        Me.Panel3.Size = New System.Drawing.Size(221, 64)
        Me.Panel3.TabIndex = 20
        Me.Panel3.Visible = False
        '
        'Label24
        '
        Me.Label24.Font = New System.Drawing.Font("Arial", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label24.Location = New System.Drawing.Point(5, 4)
        Me.Label24.Name = "Label24"
        Me.Label24.Size = New System.Drawing.Size(211, 18)
        Me.Label24.TabIndex = 2
        Me.Label24.Text = "Result 6"
        Me.Label24.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'Label28
        '
        Me.Label28.AutoSize = True
        Me.Label28.BackColor = System.Drawing.Color.LightGray
        Me.Label28.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.Label28.Font = New System.Drawing.Font("Arial", 18.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label28.ForeColor = System.Drawing.Color.Black
        Me.Label28.Location = New System.Drawing.Point(48, 29)
        Me.Label28.Name = "Label28"
        Me.Label28.Size = New System.Drawing.Size(126, 29)
        Me.Label28.TabIndex = 28
        Me.Label28.Text = "+000.0000"
        Me.Label28.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'TabPage4
        '
        Me.TabPage4.BackColor = System.Drawing.Color.OldLace
        Me.TabPage4.Controls.Add(Me.TableLayoutPanel4)
        Me.TabPage4.Location = New System.Drawing.Point(4, 27)
        Me.TabPage4.Name = "TabPage4"
        Me.TabPage4.Size = New System.Drawing.Size(986, 578)
        Me.TabPage4.TabIndex = 3
        Me.TabPage4.Text = "Run Chart Results 1-4"
        '
        'TableLayoutPanel4
        '
        Me.TableLayoutPanel4.ColumnCount = 1
        Me.TableLayoutPanel4.ColumnStyles.Add(New System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 100.0!))
        Me.TableLayoutPanel4.Controls.Add(Me.Panel20, 0, 3)
        Me.TableLayoutPanel4.Controls.Add(Me.Panel19, 0, 2)
        Me.TableLayoutPanel4.Controls.Add(Me.Panel18, 0, 1)
        Me.TableLayoutPanel4.Controls.Add(Me.Panel17, 0, 0)
        Me.TableLayoutPanel4.Location = New System.Drawing.Point(7, 6)
        Me.TableLayoutPanel4.Name = "TableLayoutPanel4"
        Me.TableLayoutPanel4.RowCount = 4
        Me.TableLayoutPanel4.RowStyles.Add(New System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 25.0!))
        Me.TableLayoutPanel4.RowStyles.Add(New System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 25.0!))
        Me.TableLayoutPanel4.RowStyles.Add(New System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 25.0!))
        Me.TableLayoutPanel4.RowStyles.Add(New System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 25.0!))
        Me.TableLayoutPanel4.RowStyles.Add(New System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 20.0!))
        Me.TableLayoutPanel4.RowStyles.Add(New System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 20.0!))
        Me.TableLayoutPanel4.RowStyles.Add(New System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 20.0!))
        Me.TableLayoutPanel4.RowStyles.Add(New System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 20.0!))
        Me.TableLayoutPanel4.Size = New System.Drawing.Size(974, 564)
        Me.TableLayoutPanel4.TabIndex = 2
        '
        'Panel20
        '
        Me.Panel20.BackColor = System.Drawing.Color.OldLace
        Me.Panel20.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.Panel20.Controls.Add(Me.Label153)
        Me.Panel20.Controls.Add(Me.Label156)
        Me.Panel20.Controls.Add(Me.Label157)
        Me.Panel20.Controls.Add(Me.Label161)
        Me.Panel20.Controls.Add(Me.Label162)
        Me.Panel20.Controls.Add(Me.Label152)
        Me.Panel20.Controls.Add(Me.Label154)
        Me.Panel20.Controls.Add(Me.Label155)
        Me.Panel20.Controls.Add(Me.Label158)
        Me.Panel20.Controls.Add(Me.Label159)
        Me.Panel20.Controls.Add(Me.Label163)
        Me.Panel20.Controls.Add(Me.Label164)
        Me.Panel20.Controls.Add(Me.RunChart4)
        Me.Panel20.Location = New System.Drawing.Point(3, 426)
        Me.Panel20.Name = "Panel20"
        Me.Panel20.Size = New System.Drawing.Size(966, 135)
        Me.Panel20.TabIndex = 4
        Me.Panel20.Visible = False
        '
        'Label153
        '
        Me.Label153.BackColor = System.Drawing.Color.Transparent
        Me.Label153.Location = New System.Drawing.Point(797, 107)
        Me.Label153.Name = "Label153"
        Me.Label153.Size = New System.Drawing.Size(56, 16)
        Me.Label153.TabIndex = 45
        Me.Label153.Text = "LSL"
        Me.Label153.TextAlign = System.Drawing.ContentAlignment.MiddleLeft
        '
        'Label156
        '
        Me.Label156.BackColor = System.Drawing.Color.Transparent
        Me.Label156.Location = New System.Drawing.Point(797, 59)
        Me.Label156.Name = "Label156"
        Me.Label156.Size = New System.Drawing.Size(56, 16)
        Me.Label156.TabIndex = 43
        Me.Label156.Text = "NOM"
        Me.Label156.TextAlign = System.Drawing.ContentAlignment.MiddleLeft
        '
        'Label157
        '
        Me.Label157.BackColor = System.Drawing.Color.Transparent
        Me.Label157.Location = New System.Drawing.Point(797, 84)
        Me.Label157.Name = "Label157"
        Me.Label157.Size = New System.Drawing.Size(56, 16)
        Me.Label157.TabIndex = 44
        Me.Label157.Text = "LCL"
        Me.Label157.TextAlign = System.Drawing.ContentAlignment.MiddleLeft
        '
        'Label161
        '
        Me.Label161.BackColor = System.Drawing.Color.Transparent
        Me.Label161.Location = New System.Drawing.Point(797, 12)
        Me.Label161.Name = "Label161"
        Me.Label161.Size = New System.Drawing.Size(56, 16)
        Me.Label161.TabIndex = 41
        Me.Label161.Text = "USL"
        Me.Label161.TextAlign = System.Drawing.ContentAlignment.MiddleLeft
        '
        'Label162
        '
        Me.Label162.BackColor = System.Drawing.Color.Transparent
        Me.Label162.Location = New System.Drawing.Point(797, 36)
        Me.Label162.Name = "Label162"
        Me.Label162.Size = New System.Drawing.Size(56, 16)
        Me.Label162.TabIndex = 42
        Me.Label162.Text = "UCL"
        Me.Label162.TextAlign = System.Drawing.ContentAlignment.MiddleLeft
        '
        'Label152
        '
        Me.Label152.BackColor = System.Drawing.Color.Transparent
        Me.Label152.Location = New System.Drawing.Point(859, 108)
        Me.Label152.Name = "Label152"
        Me.Label152.Size = New System.Drawing.Size(93, 16)
        Me.Label152.TabIndex = 39
        Me.Label152.Text = "-0.5"
        Me.Label152.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'Label154
        '
        Me.Label154.BackColor = System.Drawing.Color.Transparent
        Me.Label154.Location = New System.Drawing.Point(859, 60)
        Me.Label154.Name = "Label154"
        Me.Label154.Size = New System.Drawing.Size(93, 16)
        Me.Label154.TabIndex = 35
        Me.Label154.Text = "1.5"
        Me.Label154.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'Label155
        '
        Me.Label155.BackColor = System.Drawing.Color.Transparent
        Me.Label155.Location = New System.Drawing.Point(859, 85)
        Me.Label155.Name = "Label155"
        Me.Label155.Size = New System.Drawing.Size(93, 16)
        Me.Label155.TabIndex = 36
        Me.Label155.Text = "-0.5"
        Me.Label155.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'Label158
        '
        Me.Label158.BackColor = System.Drawing.Color.Transparent
        Me.Label158.Location = New System.Drawing.Point(859, 12)
        Me.Label158.Name = "Label158"
        Me.Label158.Size = New System.Drawing.Size(93, 16)
        Me.Label158.TabIndex = 29
        Me.Label158.Text = "1.5"
        Me.Label158.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'Label159
        '
        Me.Label159.BackColor = System.Drawing.Color.Transparent
        Me.Label159.Location = New System.Drawing.Point(859, 37)
        Me.Label159.Name = "Label159"
        Me.Label159.Size = New System.Drawing.Size(93, 16)
        Me.Label159.TabIndex = 30
        Me.Label159.Text = "-0.5"
        Me.Label159.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'Label163
        '
        Me.Label163.BackColor = System.Drawing.Color.LightGray
        Me.Label163.Font = New System.Drawing.Font("Arial", 18.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label163.ForeColor = System.Drawing.Color.Black
        Me.Label163.Location = New System.Drawing.Point(7, 37)
        Me.Label163.Name = "Label163"
        Me.Label163.Size = New System.Drawing.Size(180, 55)
        Me.Label163.TabIndex = 34
        Me.Label163.Text = "+000.0000"
        Me.Label163.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'Label164
        '
        Me.Label164.Location = New System.Drawing.Point(3, 5)
        Me.Label164.Name = "Label164"
        Me.Label164.Size = New System.Drawing.Size(184, 23)
        Me.Label164.TabIndex = 4
        Me.Label164.Text = "Result 4"
        Me.Label164.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'RunChart4
        '
        Me.RunChart4.BackColor = System.Drawing.Color.Black
        Me.RunChart4.Clickable = True
        Me.RunChart4.ControlCause = 0.0!
        Me.RunChart4.Location = New System.Drawing.Point(193, 3)
        Me.RunChart4.Name = "RunChart4"
        Me.RunChart4.RunChartCurrentSampleCount = 50
        Me.RunChart4.RunChartLCL = -0.025!
        Me.RunChart4.RunChartLCLColor = System.Drawing.Color.Gold
        Me.RunChart4.RunChartLSL = -0.04!
        Me.RunChart4.RunChartLSLColor = System.Drawing.Color.Red
        Me.RunChart4.RunChartNominal = 0.0!
        Me.RunChart4.RunChartNominalColor = System.Drawing.Color.Lime
        Me.RunChart4.RunChartSamplesValue = 0.0!
        Me.RunChart4.RunChartTotalSampleCount = 50
        Me.RunChart4.RunChartUCL = 0.025!
        Me.RunChart4.RunChartUCLColor = System.Drawing.Color.Gold
        Me.RunChart4.RunChartUSL = 0.04!
        Me.RunChart4.RunChartUSLColor = System.Drawing.Color.Red
        Me.RunChart4.Size = New System.Drawing.Size(598, 124)
        Me.RunChart4.TabIndex = 0
        '
        'Panel19
        '
        Me.Panel19.BackColor = System.Drawing.Color.OldLace
        Me.Panel19.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.Panel19.Controls.Add(Me.Label140)
        Me.Panel19.Controls.Add(Me.Label143)
        Me.Panel19.Controls.Add(Me.Label144)
        Me.Panel19.Controls.Add(Me.Label148)
        Me.Panel19.Controls.Add(Me.Label149)
        Me.Panel19.Controls.Add(Me.Label139)
        Me.Panel19.Controls.Add(Me.Label141)
        Me.Panel19.Controls.Add(Me.Label142)
        Me.Panel19.Controls.Add(Me.Label145)
        Me.Panel19.Controls.Add(Me.Label146)
        Me.Panel19.Controls.Add(Me.Label150)
        Me.Panel19.Controls.Add(Me.Label151)
        Me.Panel19.Controls.Add(Me.RunChart3)
        Me.Panel19.Location = New System.Drawing.Point(3, 285)
        Me.Panel19.Name = "Panel19"
        Me.Panel19.Size = New System.Drawing.Size(966, 135)
        Me.Panel19.TabIndex = 3
        Me.Panel19.Visible = False
        '
        'Label140
        '
        Me.Label140.BackColor = System.Drawing.Color.Transparent
        Me.Label140.Location = New System.Drawing.Point(797, 107)
        Me.Label140.Name = "Label140"
        Me.Label140.Size = New System.Drawing.Size(56, 16)
        Me.Label140.TabIndex = 45
        Me.Label140.Text = "LSL"
        Me.Label140.TextAlign = System.Drawing.ContentAlignment.MiddleLeft
        '
        'Label143
        '
        Me.Label143.BackColor = System.Drawing.Color.Transparent
        Me.Label143.Location = New System.Drawing.Point(797, 59)
        Me.Label143.Name = "Label143"
        Me.Label143.Size = New System.Drawing.Size(56, 16)
        Me.Label143.TabIndex = 43
        Me.Label143.Text = "NOM"
        Me.Label143.TextAlign = System.Drawing.ContentAlignment.MiddleLeft
        '
        'Label144
        '
        Me.Label144.BackColor = System.Drawing.Color.Transparent
        Me.Label144.Location = New System.Drawing.Point(797, 84)
        Me.Label144.Name = "Label144"
        Me.Label144.Size = New System.Drawing.Size(56, 16)
        Me.Label144.TabIndex = 44
        Me.Label144.Text = "LCL"
        Me.Label144.TextAlign = System.Drawing.ContentAlignment.MiddleLeft
        '
        'Label148
        '
        Me.Label148.BackColor = System.Drawing.Color.Transparent
        Me.Label148.Location = New System.Drawing.Point(797, 12)
        Me.Label148.Name = "Label148"
        Me.Label148.Size = New System.Drawing.Size(56, 16)
        Me.Label148.TabIndex = 41
        Me.Label148.Text = "USL"
        Me.Label148.TextAlign = System.Drawing.ContentAlignment.MiddleLeft
        '
        'Label149
        '
        Me.Label149.BackColor = System.Drawing.Color.Transparent
        Me.Label149.Location = New System.Drawing.Point(797, 36)
        Me.Label149.Name = "Label149"
        Me.Label149.Size = New System.Drawing.Size(56, 16)
        Me.Label149.TabIndex = 42
        Me.Label149.Text = "UCL"
        Me.Label149.TextAlign = System.Drawing.ContentAlignment.MiddleLeft
        '
        'Label139
        '
        Me.Label139.BackColor = System.Drawing.Color.Transparent
        Me.Label139.Location = New System.Drawing.Point(859, 108)
        Me.Label139.Name = "Label139"
        Me.Label139.Size = New System.Drawing.Size(93, 16)
        Me.Label139.TabIndex = 39
        Me.Label139.Text = "-0.5"
        Me.Label139.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'Label141
        '
        Me.Label141.BackColor = System.Drawing.Color.Transparent
        Me.Label141.Location = New System.Drawing.Point(859, 60)
        Me.Label141.Name = "Label141"
        Me.Label141.Size = New System.Drawing.Size(93, 16)
        Me.Label141.TabIndex = 35
        Me.Label141.Text = "1.5"
        Me.Label141.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'Label142
        '
        Me.Label142.BackColor = System.Drawing.Color.Transparent
        Me.Label142.Location = New System.Drawing.Point(859, 85)
        Me.Label142.Name = "Label142"
        Me.Label142.Size = New System.Drawing.Size(93, 16)
        Me.Label142.TabIndex = 36
        Me.Label142.Text = "-0.5"
        Me.Label142.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'Label145
        '
        Me.Label145.BackColor = System.Drawing.Color.Transparent
        Me.Label145.Location = New System.Drawing.Point(859, 12)
        Me.Label145.Name = "Label145"
        Me.Label145.Size = New System.Drawing.Size(93, 16)
        Me.Label145.TabIndex = 29
        Me.Label145.Text = "1.5"
        Me.Label145.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'Label146
        '
        Me.Label146.BackColor = System.Drawing.Color.Transparent
        Me.Label146.Location = New System.Drawing.Point(859, 37)
        Me.Label146.Name = "Label146"
        Me.Label146.Size = New System.Drawing.Size(93, 16)
        Me.Label146.TabIndex = 30
        Me.Label146.Text = "-0.5"
        Me.Label146.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'Label150
        '
        Me.Label150.BackColor = System.Drawing.Color.LightGray
        Me.Label150.Font = New System.Drawing.Font("Arial", 18.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label150.ForeColor = System.Drawing.Color.Black
        Me.Label150.Location = New System.Drawing.Point(7, 37)
        Me.Label150.Name = "Label150"
        Me.Label150.Size = New System.Drawing.Size(180, 55)
        Me.Label150.TabIndex = 34
        Me.Label150.Text = "+000.0000"
        Me.Label150.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'Label151
        '
        Me.Label151.Location = New System.Drawing.Point(3, 5)
        Me.Label151.Name = "Label151"
        Me.Label151.Size = New System.Drawing.Size(184, 23)
        Me.Label151.TabIndex = 4
        Me.Label151.Text = "Result 3"
        Me.Label151.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'RunChart3
        '
        Me.RunChart3.BackColor = System.Drawing.Color.Black
        Me.RunChart3.Clickable = True
        Me.RunChart3.ControlCause = 0.0!
        Me.RunChart3.Location = New System.Drawing.Point(193, 5)
        Me.RunChart3.Name = "RunChart3"
        Me.RunChart3.RunChartCurrentSampleCount = 50
        Me.RunChart3.RunChartLCL = -0.025!
        Me.RunChart3.RunChartLCLColor = System.Drawing.Color.Gold
        Me.RunChart3.RunChartLSL = -0.04!
        Me.RunChart3.RunChartLSLColor = System.Drawing.Color.Red
        Me.RunChart3.RunChartNominal = 0.0!
        Me.RunChart3.RunChartNominalColor = System.Drawing.Color.Lime
        Me.RunChart3.RunChartSamplesValue = 0.0!
        Me.RunChart3.RunChartTotalSampleCount = 50
        Me.RunChart3.RunChartUCL = 0.025!
        Me.RunChart3.RunChartUCLColor = System.Drawing.Color.Gold
        Me.RunChart3.RunChartUSL = 0.04!
        Me.RunChart3.RunChartUSLColor = System.Drawing.Color.Red
        Me.RunChart3.Size = New System.Drawing.Size(598, 124)
        Me.RunChart3.TabIndex = 0
        '
        'Panel18
        '
        Me.Panel18.BackColor = System.Drawing.Color.OldLace
        Me.Panel18.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.Panel18.Controls.Add(Me.Label127)
        Me.Panel18.Controls.Add(Me.Label130)
        Me.Panel18.Controls.Add(Me.Label131)
        Me.Panel18.Controls.Add(Me.Label135)
        Me.Panel18.Controls.Add(Me.Label136)
        Me.Panel18.Controls.Add(Me.Label126)
        Me.Panel18.Controls.Add(Me.Label128)
        Me.Panel18.Controls.Add(Me.Label129)
        Me.Panel18.Controls.Add(Me.Label132)
        Me.Panel18.Controls.Add(Me.Label133)
        Me.Panel18.Controls.Add(Me.Label137)
        Me.Panel18.Controls.Add(Me.Label138)
        Me.Panel18.Controls.Add(Me.RunChart2)
        Me.Panel18.Location = New System.Drawing.Point(3, 144)
        Me.Panel18.Name = "Panel18"
        Me.Panel18.Size = New System.Drawing.Size(966, 135)
        Me.Panel18.TabIndex = 2
        Me.Panel18.Visible = False
        '
        'Label127
        '
        Me.Label127.BackColor = System.Drawing.Color.Transparent
        Me.Label127.Location = New System.Drawing.Point(797, 107)
        Me.Label127.Name = "Label127"
        Me.Label127.Size = New System.Drawing.Size(56, 16)
        Me.Label127.TabIndex = 45
        Me.Label127.Text = "LSL"
        Me.Label127.TextAlign = System.Drawing.ContentAlignment.MiddleLeft
        '
        'Label130
        '
        Me.Label130.BackColor = System.Drawing.Color.Transparent
        Me.Label130.Location = New System.Drawing.Point(797, 59)
        Me.Label130.Name = "Label130"
        Me.Label130.Size = New System.Drawing.Size(56, 16)
        Me.Label130.TabIndex = 43
        Me.Label130.Text = "NOM"
        Me.Label130.TextAlign = System.Drawing.ContentAlignment.MiddleLeft
        '
        'Label131
        '
        Me.Label131.BackColor = System.Drawing.Color.Transparent
        Me.Label131.Location = New System.Drawing.Point(797, 84)
        Me.Label131.Name = "Label131"
        Me.Label131.Size = New System.Drawing.Size(56, 16)
        Me.Label131.TabIndex = 44
        Me.Label131.Text = "LCL"
        Me.Label131.TextAlign = System.Drawing.ContentAlignment.MiddleLeft
        '
        'Label135
        '
        Me.Label135.BackColor = System.Drawing.Color.Transparent
        Me.Label135.Location = New System.Drawing.Point(797, 12)
        Me.Label135.Name = "Label135"
        Me.Label135.Size = New System.Drawing.Size(56, 16)
        Me.Label135.TabIndex = 41
        Me.Label135.Text = "USL"
        Me.Label135.TextAlign = System.Drawing.ContentAlignment.MiddleLeft
        '
        'Label136
        '
        Me.Label136.BackColor = System.Drawing.Color.Transparent
        Me.Label136.Location = New System.Drawing.Point(797, 36)
        Me.Label136.Name = "Label136"
        Me.Label136.Size = New System.Drawing.Size(56, 16)
        Me.Label136.TabIndex = 42
        Me.Label136.Text = "UCL"
        Me.Label136.TextAlign = System.Drawing.ContentAlignment.MiddleLeft
        '
        'Label126
        '
        Me.Label126.BackColor = System.Drawing.Color.Transparent
        Me.Label126.Location = New System.Drawing.Point(859, 108)
        Me.Label126.Name = "Label126"
        Me.Label126.Size = New System.Drawing.Size(93, 16)
        Me.Label126.TabIndex = 39
        Me.Label126.Text = "-0.5"
        Me.Label126.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'Label128
        '
        Me.Label128.BackColor = System.Drawing.Color.Transparent
        Me.Label128.Location = New System.Drawing.Point(859, 60)
        Me.Label128.Name = "Label128"
        Me.Label128.Size = New System.Drawing.Size(93, 16)
        Me.Label128.TabIndex = 35
        Me.Label128.Text = "1.5"
        Me.Label128.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'Label129
        '
        Me.Label129.BackColor = System.Drawing.Color.Transparent
        Me.Label129.Location = New System.Drawing.Point(859, 85)
        Me.Label129.Name = "Label129"
        Me.Label129.Size = New System.Drawing.Size(93, 16)
        Me.Label129.TabIndex = 36
        Me.Label129.Text = "-0.5"
        Me.Label129.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'Label132
        '
        Me.Label132.BackColor = System.Drawing.Color.Transparent
        Me.Label132.Location = New System.Drawing.Point(859, 12)
        Me.Label132.Name = "Label132"
        Me.Label132.Size = New System.Drawing.Size(93, 16)
        Me.Label132.TabIndex = 29
        Me.Label132.Text = "1.5"
        Me.Label132.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'Label133
        '
        Me.Label133.BackColor = System.Drawing.Color.Transparent
        Me.Label133.Location = New System.Drawing.Point(859, 37)
        Me.Label133.Name = "Label133"
        Me.Label133.Size = New System.Drawing.Size(93, 16)
        Me.Label133.TabIndex = 30
        Me.Label133.Text = "-0.5"
        Me.Label133.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'Label137
        '
        Me.Label137.BackColor = System.Drawing.Color.LightGray
        Me.Label137.Font = New System.Drawing.Font("Arial", 18.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label137.ForeColor = System.Drawing.Color.Black
        Me.Label137.Location = New System.Drawing.Point(7, 37)
        Me.Label137.Name = "Label137"
        Me.Label137.Size = New System.Drawing.Size(180, 55)
        Me.Label137.TabIndex = 34
        Me.Label137.Text = "+000.0000"
        Me.Label137.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'Label138
        '
        Me.Label138.Location = New System.Drawing.Point(3, 5)
        Me.Label138.Name = "Label138"
        Me.Label138.Size = New System.Drawing.Size(184, 23)
        Me.Label138.TabIndex = 4
        Me.Label138.Text = "Result 2"
        Me.Label138.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'RunChart2
        '
        Me.RunChart2.BackColor = System.Drawing.Color.Black
        Me.RunChart2.Clickable = True
        Me.RunChart2.ControlCause = 0.0!
        Me.RunChart2.Location = New System.Drawing.Point(193, 5)
        Me.RunChart2.Name = "RunChart2"
        Me.RunChart2.RunChartCurrentSampleCount = 50
        Me.RunChart2.RunChartLCL = -0.025!
        Me.RunChart2.RunChartLCLColor = System.Drawing.Color.Gold
        Me.RunChart2.RunChartLSL = -0.04!
        Me.RunChart2.RunChartLSLColor = System.Drawing.Color.Red
        Me.RunChart2.RunChartNominal = 0.0!
        Me.RunChart2.RunChartNominalColor = System.Drawing.Color.Lime
        Me.RunChart2.RunChartSamplesValue = 0.0!
        Me.RunChart2.RunChartTotalSampleCount = 50
        Me.RunChart2.RunChartUCL = 0.025!
        Me.RunChart2.RunChartUCLColor = System.Drawing.Color.Gold
        Me.RunChart2.RunChartUSL = 0.04!
        Me.RunChart2.RunChartUSLColor = System.Drawing.Color.Red
        Me.RunChart2.Size = New System.Drawing.Size(598, 124)
        Me.RunChart2.TabIndex = 0
        '
        'Panel17
        '
        Me.Panel17.BackColor = System.Drawing.Color.OldLace
        Me.Panel17.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.Panel17.Controls.Add(Me.Label124)
        Me.Panel17.Controls.Add(Me.Label125)
        Me.Panel17.Controls.Add(Me.Label120)
        Me.Panel17.Controls.Add(Me.Label121)
        Me.Panel17.Controls.Add(Me.Label122)
        Me.Panel17.Controls.Add(Me.Label123)
        Me.Panel17.Controls.Add(Me.Label114)
        Me.Panel17.Controls.Add(Me.Label115)
        Me.Panel17.Controls.Add(Me.Label117)
        Me.Panel17.Controls.Add(Me.Label118)
        Me.Panel17.Controls.Add(Me.Label119)
        Me.Panel17.Controls.Add(Me.Label105)
        Me.Panel17.Controls.Add(Me.RunChart1)
        Me.Panel17.Location = New System.Drawing.Point(3, 3)
        Me.Panel17.Name = "Panel17"
        Me.Panel17.Size = New System.Drawing.Size(966, 135)
        Me.Panel17.TabIndex = 1
        Me.Panel17.Visible = False
        '
        'Label124
        '
        Me.Label124.BackColor = System.Drawing.Color.Transparent
        Me.Label124.Location = New System.Drawing.Point(859, 108)
        Me.Label124.Name = "Label124"
        Me.Label124.Size = New System.Drawing.Size(93, 16)
        Me.Label124.TabIndex = 39
        Me.Label124.Text = "-0.5"
        Me.Label124.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'Label125
        '
        Me.Label125.BackColor = System.Drawing.Color.Transparent
        Me.Label125.Location = New System.Drawing.Point(797, 108)
        Me.Label125.Name = "Label125"
        Me.Label125.Size = New System.Drawing.Size(56, 16)
        Me.Label125.TabIndex = 40
        Me.Label125.Text = "LSL"
        Me.Label125.TextAlign = System.Drawing.ContentAlignment.MiddleLeft
        '
        'Label120
        '
        Me.Label120.BackColor = System.Drawing.Color.Transparent
        Me.Label120.Location = New System.Drawing.Point(859, 60)
        Me.Label120.Name = "Label120"
        Me.Label120.Size = New System.Drawing.Size(93, 16)
        Me.Label120.TabIndex = 35
        Me.Label120.Text = "1.5"
        Me.Label120.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'Label121
        '
        Me.Label121.BackColor = System.Drawing.Color.Transparent
        Me.Label121.Location = New System.Drawing.Point(859, 85)
        Me.Label121.Name = "Label121"
        Me.Label121.Size = New System.Drawing.Size(93, 16)
        Me.Label121.TabIndex = 36
        Me.Label121.Text = "-0.5"
        Me.Label121.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'Label122
        '
        Me.Label122.BackColor = System.Drawing.Color.Transparent
        Me.Label122.Location = New System.Drawing.Point(797, 60)
        Me.Label122.Name = "Label122"
        Me.Label122.Size = New System.Drawing.Size(56, 16)
        Me.Label122.TabIndex = 37
        Me.Label122.Text = "NOM"
        Me.Label122.TextAlign = System.Drawing.ContentAlignment.MiddleLeft
        '
        'Label123
        '
        Me.Label123.BackColor = System.Drawing.Color.Transparent
        Me.Label123.Location = New System.Drawing.Point(797, 85)
        Me.Label123.Name = "Label123"
        Me.Label123.Size = New System.Drawing.Size(56, 16)
        Me.Label123.TabIndex = 38
        Me.Label123.Text = "LCL"
        Me.Label123.TextAlign = System.Drawing.ContentAlignment.MiddleLeft
        '
        'Label114
        '
        Me.Label114.BackColor = System.Drawing.Color.Transparent
        Me.Label114.Location = New System.Drawing.Point(859, 12)
        Me.Label114.Name = "Label114"
        Me.Label114.Size = New System.Drawing.Size(93, 16)
        Me.Label114.TabIndex = 29
        Me.Label114.Text = "1.5"
        Me.Label114.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'Label115
        '
        Me.Label115.BackColor = System.Drawing.Color.Transparent
        Me.Label115.Location = New System.Drawing.Point(859, 37)
        Me.Label115.Name = "Label115"
        Me.Label115.Size = New System.Drawing.Size(93, 16)
        Me.Label115.TabIndex = 30
        Me.Label115.Text = "-0.5"
        Me.Label115.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'Label117
        '
        Me.Label117.BackColor = System.Drawing.Color.Transparent
        Me.Label117.Location = New System.Drawing.Point(797, 13)
        Me.Label117.Name = "Label117"
        Me.Label117.Size = New System.Drawing.Size(56, 16)
        Me.Label117.TabIndex = 32
        Me.Label117.Text = "USL"
        Me.Label117.TextAlign = System.Drawing.ContentAlignment.MiddleLeft
        '
        'Label118
        '
        Me.Label118.BackColor = System.Drawing.Color.Transparent
        Me.Label118.Location = New System.Drawing.Point(797, 37)
        Me.Label118.Name = "Label118"
        Me.Label118.Size = New System.Drawing.Size(56, 16)
        Me.Label118.TabIndex = 33
        Me.Label118.Text = "UCL"
        Me.Label118.TextAlign = System.Drawing.ContentAlignment.MiddleLeft
        '
        'Label119
        '
        Me.Label119.BackColor = System.Drawing.Color.LightGray
        Me.Label119.Font = New System.Drawing.Font("Arial", 18.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label119.ForeColor = System.Drawing.Color.Black
        Me.Label119.Location = New System.Drawing.Point(7, 37)
        Me.Label119.Name = "Label119"
        Me.Label119.Size = New System.Drawing.Size(180, 55)
        Me.Label119.TabIndex = 34
        Me.Label119.Text = "+000.0000"
        Me.Label119.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'Label105
        '
        Me.Label105.Location = New System.Drawing.Point(3, 5)
        Me.Label105.Name = "Label105"
        Me.Label105.Size = New System.Drawing.Size(184, 23)
        Me.Label105.TabIndex = 4
        Me.Label105.Text = "Result 1"
        Me.Label105.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'RunChart1
        '
        Me.RunChart1.BackColor = System.Drawing.Color.Black
        Me.RunChart1.Clickable = True
        Me.RunChart1.ControlCause = 0.0!
        Me.RunChart1.Location = New System.Drawing.Point(193, 6)
        Me.RunChart1.Name = "RunChart1"
        Me.RunChart1.RunChartCurrentSampleCount = 50
        Me.RunChart1.RunChartLCL = -0.025!
        Me.RunChart1.RunChartLCLColor = System.Drawing.Color.Gold
        Me.RunChart1.RunChartLSL = -0.04!
        Me.RunChart1.RunChartLSLColor = System.Drawing.Color.Red
        Me.RunChart1.RunChartNominal = 0.0!
        Me.RunChart1.RunChartNominalColor = System.Drawing.Color.Lime
        Me.RunChart1.RunChartSamplesValue = 0.0!
        Me.RunChart1.RunChartTotalSampleCount = 50
        Me.RunChart1.RunChartUCL = 0.025!
        Me.RunChart1.RunChartUCLColor = System.Drawing.Color.Gold
        Me.RunChart1.RunChartUSL = 0.04!
        Me.RunChart1.RunChartUSLColor = System.Drawing.Color.Red
        Me.RunChart1.Size = New System.Drawing.Size(598, 124)
        Me.RunChart1.TabIndex = 0
        '
        'TabPage5
        '
        Me.TabPage5.BackColor = System.Drawing.Color.OldLace
        Me.TabPage5.Controls.Add(Me.TableLayoutPanel6)
        Me.TabPage5.Location = New System.Drawing.Point(4, 27)
        Me.TabPage5.Name = "TabPage5"
        Me.TabPage5.Size = New System.Drawing.Size(986, 578)
        Me.TabPage5.TabIndex = 4
        Me.TabPage5.Text = "Run Chart Results 5-8"
        '
        'TableLayoutPanel6
        '
        Me.TableLayoutPanel6.ColumnCount = 1
        Me.TableLayoutPanel6.ColumnStyles.Add(New System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 100.0!))
        Me.TableLayoutPanel6.Controls.Add(Me.Panel25, 0, 3)
        Me.TableLayoutPanel6.Controls.Add(Me.Panel26, 0, 2)
        Me.TableLayoutPanel6.Controls.Add(Me.Panel27, 0, 1)
        Me.TableLayoutPanel6.Controls.Add(Me.Panel28, 0, 0)
        Me.TableLayoutPanel6.Location = New System.Drawing.Point(7, 6)
        Me.TableLayoutPanel6.Name = "TableLayoutPanel6"
        Me.TableLayoutPanel6.RowCount = 4
        Me.TableLayoutPanel6.RowStyles.Add(New System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 25.0!))
        Me.TableLayoutPanel6.RowStyles.Add(New System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 25.0!))
        Me.TableLayoutPanel6.RowStyles.Add(New System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 25.0!))
        Me.TableLayoutPanel6.RowStyles.Add(New System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 25.0!))
        Me.TableLayoutPanel6.RowStyles.Add(New System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 20.0!))
        Me.TableLayoutPanel6.RowStyles.Add(New System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 20.0!))
        Me.TableLayoutPanel6.RowStyles.Add(New System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 20.0!))
        Me.TableLayoutPanel6.RowStyles.Add(New System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 20.0!))
        Me.TableLayoutPanel6.Size = New System.Drawing.Size(974, 564)
        Me.TableLayoutPanel6.TabIndex = 3
        '
        'Panel25
        '
        Me.Panel25.BackColor = System.Drawing.Color.OldLace
        Me.Panel25.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.Panel25.Controls.Add(Me.Label257)
        Me.Panel25.Controls.Add(Me.Label260)
        Me.Panel25.Controls.Add(Me.Label261)
        Me.Panel25.Controls.Add(Me.Label265)
        Me.Panel25.Controls.Add(Me.Label266)
        Me.Panel25.Controls.Add(Me.Label217)
        Me.Panel25.Controls.Add(Me.Label219)
        Me.Panel25.Controls.Add(Me.Label220)
        Me.Panel25.Controls.Add(Me.Label223)
        Me.Panel25.Controls.Add(Me.Label224)
        Me.Panel25.Controls.Add(Me.Label228)
        Me.Panel25.Controls.Add(Me.Label229)
        Me.Panel25.Controls.Add(Me.RunChart9)
        Me.Panel25.Location = New System.Drawing.Point(3, 426)
        Me.Panel25.Name = "Panel25"
        Me.Panel25.Size = New System.Drawing.Size(966, 135)
        Me.Panel25.TabIndex = 4
        Me.Panel25.Visible = False
        '
        'Label257
        '
        Me.Label257.BackColor = System.Drawing.Color.Transparent
        Me.Label257.Location = New System.Drawing.Point(797, 107)
        Me.Label257.Name = "Label257"
        Me.Label257.Size = New System.Drawing.Size(56, 16)
        Me.Label257.TabIndex = 45
        Me.Label257.Text = "LSL"
        Me.Label257.TextAlign = System.Drawing.ContentAlignment.MiddleLeft
        '
        'Label260
        '
        Me.Label260.BackColor = System.Drawing.Color.Transparent
        Me.Label260.Location = New System.Drawing.Point(797, 59)
        Me.Label260.Name = "Label260"
        Me.Label260.Size = New System.Drawing.Size(56, 16)
        Me.Label260.TabIndex = 43
        Me.Label260.Text = "NOM"
        Me.Label260.TextAlign = System.Drawing.ContentAlignment.MiddleLeft
        '
        'Label261
        '
        Me.Label261.BackColor = System.Drawing.Color.Transparent
        Me.Label261.Location = New System.Drawing.Point(797, 84)
        Me.Label261.Name = "Label261"
        Me.Label261.Size = New System.Drawing.Size(56, 16)
        Me.Label261.TabIndex = 44
        Me.Label261.Text = "LCL"
        Me.Label261.TextAlign = System.Drawing.ContentAlignment.MiddleLeft
        '
        'Label265
        '
        Me.Label265.BackColor = System.Drawing.Color.Transparent
        Me.Label265.Location = New System.Drawing.Point(797, 12)
        Me.Label265.Name = "Label265"
        Me.Label265.Size = New System.Drawing.Size(56, 16)
        Me.Label265.TabIndex = 41
        Me.Label265.Text = "USL"
        Me.Label265.TextAlign = System.Drawing.ContentAlignment.MiddleLeft
        '
        'Label266
        '
        Me.Label266.BackColor = System.Drawing.Color.Transparent
        Me.Label266.Location = New System.Drawing.Point(797, 36)
        Me.Label266.Name = "Label266"
        Me.Label266.Size = New System.Drawing.Size(56, 16)
        Me.Label266.TabIndex = 42
        Me.Label266.Text = "UCL"
        Me.Label266.TextAlign = System.Drawing.ContentAlignment.MiddleLeft
        '
        'Label217
        '
        Me.Label217.BackColor = System.Drawing.Color.Transparent
        Me.Label217.Location = New System.Drawing.Point(859, 108)
        Me.Label217.Name = "Label217"
        Me.Label217.Size = New System.Drawing.Size(93, 16)
        Me.Label217.TabIndex = 39
        Me.Label217.Text = "-0.5"
        Me.Label217.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'Label219
        '
        Me.Label219.BackColor = System.Drawing.Color.Transparent
        Me.Label219.Location = New System.Drawing.Point(859, 60)
        Me.Label219.Name = "Label219"
        Me.Label219.Size = New System.Drawing.Size(93, 16)
        Me.Label219.TabIndex = 35
        Me.Label219.Text = "1.5"
        Me.Label219.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'Label220
        '
        Me.Label220.BackColor = System.Drawing.Color.Transparent
        Me.Label220.Location = New System.Drawing.Point(859, 85)
        Me.Label220.Name = "Label220"
        Me.Label220.Size = New System.Drawing.Size(93, 16)
        Me.Label220.TabIndex = 36
        Me.Label220.Text = "-0.5"
        Me.Label220.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'Label223
        '
        Me.Label223.BackColor = System.Drawing.Color.Transparent
        Me.Label223.Location = New System.Drawing.Point(859, 12)
        Me.Label223.Name = "Label223"
        Me.Label223.Size = New System.Drawing.Size(93, 16)
        Me.Label223.TabIndex = 29
        Me.Label223.Text = "1.5"
        Me.Label223.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'Label224
        '
        Me.Label224.BackColor = System.Drawing.Color.Transparent
        Me.Label224.Location = New System.Drawing.Point(859, 37)
        Me.Label224.Name = "Label224"
        Me.Label224.Size = New System.Drawing.Size(93, 16)
        Me.Label224.TabIndex = 30
        Me.Label224.Text = "-0.5"
        Me.Label224.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'Label228
        '
        Me.Label228.BackColor = System.Drawing.Color.LightGray
        Me.Label228.Font = New System.Drawing.Font("Arial", 18.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label228.ForeColor = System.Drawing.Color.Black
        Me.Label228.Location = New System.Drawing.Point(7, 37)
        Me.Label228.Name = "Label228"
        Me.Label228.Size = New System.Drawing.Size(180, 55)
        Me.Label228.TabIndex = 34
        Me.Label228.Text = "+000.0000"
        Me.Label228.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'Label229
        '
        Me.Label229.Location = New System.Drawing.Point(3, 5)
        Me.Label229.Name = "Label229"
        Me.Label229.Size = New System.Drawing.Size(184, 23)
        Me.Label229.TabIndex = 4
        Me.Label229.Text = "Result 8"
        Me.Label229.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'RunChart9
        '
        Me.RunChart9.BackColor = System.Drawing.Color.Black
        Me.RunChart9.Clickable = True
        Me.RunChart9.ControlCause = 0.0!
        Me.RunChart9.Location = New System.Drawing.Point(193, 5)
        Me.RunChart9.Name = "RunChart9"
        Me.RunChart9.RunChartCurrentSampleCount = 50
        Me.RunChart9.RunChartLCL = -0.025!
        Me.RunChart9.RunChartLCLColor = System.Drawing.Color.Gold
        Me.RunChart9.RunChartLSL = -0.04!
        Me.RunChart9.RunChartLSLColor = System.Drawing.Color.Red
        Me.RunChart9.RunChartNominal = 0.0!
        Me.RunChart9.RunChartNominalColor = System.Drawing.Color.Lime
        Me.RunChart9.RunChartSamplesValue = 0.0!
        Me.RunChart9.RunChartTotalSampleCount = 50
        Me.RunChart9.RunChartUCL = 0.025!
        Me.RunChart9.RunChartUCLColor = System.Drawing.Color.Gold
        Me.RunChart9.RunChartUSL = 0.04!
        Me.RunChart9.RunChartUSLColor = System.Drawing.Color.Red
        Me.RunChart9.Size = New System.Drawing.Size(598, 124)
        Me.RunChart9.TabIndex = 0
        '
        'Panel26
        '
        Me.Panel26.BackColor = System.Drawing.Color.OldLace
        Me.Panel26.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.Panel26.Controls.Add(Me.Label244)
        Me.Panel26.Controls.Add(Me.Label247)
        Me.Panel26.Controls.Add(Me.Label248)
        Me.Panel26.Controls.Add(Me.Label252)
        Me.Panel26.Controls.Add(Me.Label253)
        Me.Panel26.Controls.Add(Me.Label230)
        Me.Panel26.Controls.Add(Me.Label232)
        Me.Panel26.Controls.Add(Me.Label233)
        Me.Panel26.Controls.Add(Me.Label236)
        Me.Panel26.Controls.Add(Me.Label237)
        Me.Panel26.Controls.Add(Me.Label241)
        Me.Panel26.Controls.Add(Me.Label242)
        Me.Panel26.Controls.Add(Me.RunChart10)
        Me.Panel26.Location = New System.Drawing.Point(3, 285)
        Me.Panel26.Name = "Panel26"
        Me.Panel26.Size = New System.Drawing.Size(966, 135)
        Me.Panel26.TabIndex = 3
        Me.Panel26.Visible = False
        '
        'Label244
        '
        Me.Label244.BackColor = System.Drawing.Color.Transparent
        Me.Label244.Location = New System.Drawing.Point(797, 111)
        Me.Label244.Name = "Label244"
        Me.Label244.Size = New System.Drawing.Size(56, 16)
        Me.Label244.TabIndex = 45
        Me.Label244.Text = "LSL"
        Me.Label244.TextAlign = System.Drawing.ContentAlignment.MiddleLeft
        '
        'Label247
        '
        Me.Label247.BackColor = System.Drawing.Color.Transparent
        Me.Label247.Location = New System.Drawing.Point(797, 63)
        Me.Label247.Name = "Label247"
        Me.Label247.Size = New System.Drawing.Size(56, 16)
        Me.Label247.TabIndex = 43
        Me.Label247.Text = "NOM"
        Me.Label247.TextAlign = System.Drawing.ContentAlignment.MiddleLeft
        '
        'Label248
        '
        Me.Label248.BackColor = System.Drawing.Color.Transparent
        Me.Label248.Location = New System.Drawing.Point(797, 88)
        Me.Label248.Name = "Label248"
        Me.Label248.Size = New System.Drawing.Size(56, 16)
        Me.Label248.TabIndex = 44
        Me.Label248.Text = "LCL"
        Me.Label248.TextAlign = System.Drawing.ContentAlignment.MiddleLeft
        '
        'Label252
        '
        Me.Label252.BackColor = System.Drawing.Color.Transparent
        Me.Label252.Location = New System.Drawing.Point(797, 16)
        Me.Label252.Name = "Label252"
        Me.Label252.Size = New System.Drawing.Size(56, 16)
        Me.Label252.TabIndex = 41
        Me.Label252.Text = "USL"
        Me.Label252.TextAlign = System.Drawing.ContentAlignment.MiddleLeft
        '
        'Label253
        '
        Me.Label253.BackColor = System.Drawing.Color.Transparent
        Me.Label253.Location = New System.Drawing.Point(797, 40)
        Me.Label253.Name = "Label253"
        Me.Label253.Size = New System.Drawing.Size(56, 16)
        Me.Label253.TabIndex = 42
        Me.Label253.Text = "UCL"
        Me.Label253.TextAlign = System.Drawing.ContentAlignment.MiddleLeft
        '
        'Label230
        '
        Me.Label230.BackColor = System.Drawing.Color.Transparent
        Me.Label230.Location = New System.Drawing.Point(859, 108)
        Me.Label230.Name = "Label230"
        Me.Label230.Size = New System.Drawing.Size(93, 16)
        Me.Label230.TabIndex = 39
        Me.Label230.Text = "-0.5"
        Me.Label230.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'Label232
        '
        Me.Label232.BackColor = System.Drawing.Color.Transparent
        Me.Label232.Location = New System.Drawing.Point(859, 60)
        Me.Label232.Name = "Label232"
        Me.Label232.Size = New System.Drawing.Size(93, 16)
        Me.Label232.TabIndex = 35
        Me.Label232.Text = "1.5"
        Me.Label232.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'Label233
        '
        Me.Label233.BackColor = System.Drawing.Color.Transparent
        Me.Label233.Location = New System.Drawing.Point(859, 85)
        Me.Label233.Name = "Label233"
        Me.Label233.Size = New System.Drawing.Size(93, 16)
        Me.Label233.TabIndex = 36
        Me.Label233.Text = "-0.5"
        Me.Label233.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'Label236
        '
        Me.Label236.BackColor = System.Drawing.Color.Transparent
        Me.Label236.Location = New System.Drawing.Point(859, 12)
        Me.Label236.Name = "Label236"
        Me.Label236.Size = New System.Drawing.Size(93, 16)
        Me.Label236.TabIndex = 29
        Me.Label236.Text = "1.5"
        Me.Label236.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'Label237
        '
        Me.Label237.BackColor = System.Drawing.Color.Transparent
        Me.Label237.Location = New System.Drawing.Point(859, 37)
        Me.Label237.Name = "Label237"
        Me.Label237.Size = New System.Drawing.Size(93, 16)
        Me.Label237.TabIndex = 30
        Me.Label237.Text = "-0.5"
        Me.Label237.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'Label241
        '
        Me.Label241.BackColor = System.Drawing.Color.LightGray
        Me.Label241.Font = New System.Drawing.Font("Arial", 18.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label241.ForeColor = System.Drawing.Color.Black
        Me.Label241.Location = New System.Drawing.Point(7, 37)
        Me.Label241.Name = "Label241"
        Me.Label241.Size = New System.Drawing.Size(180, 55)
        Me.Label241.TabIndex = 34
        Me.Label241.Text = "+000.0000"
        Me.Label241.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'Label242
        '
        Me.Label242.Location = New System.Drawing.Point(3, 5)
        Me.Label242.Name = "Label242"
        Me.Label242.Size = New System.Drawing.Size(184, 23)
        Me.Label242.TabIndex = 4
        Me.Label242.Text = "Result 7"
        Me.Label242.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'RunChart10
        '
        Me.RunChart10.BackColor = System.Drawing.Color.Black
        Me.RunChart10.Clickable = True
        Me.RunChart10.ControlCause = 0.0!
        Me.RunChart10.Location = New System.Drawing.Point(193, 5)
        Me.RunChart10.Name = "RunChart10"
        Me.RunChart10.RunChartCurrentSampleCount = 50
        Me.RunChart10.RunChartLCL = -0.025!
        Me.RunChart10.RunChartLCLColor = System.Drawing.Color.Gold
        Me.RunChart10.RunChartLSL = -0.04!
        Me.RunChart10.RunChartLSLColor = System.Drawing.Color.Red
        Me.RunChart10.RunChartNominal = 0.0!
        Me.RunChart10.RunChartNominalColor = System.Drawing.Color.Lime
        Me.RunChart10.RunChartSamplesValue = 0.0!
        Me.RunChart10.RunChartTotalSampleCount = 50
        Me.RunChart10.RunChartUCL = 0.025!
        Me.RunChart10.RunChartUCLColor = System.Drawing.Color.Gold
        Me.RunChart10.RunChartUSL = 0.04!
        Me.RunChart10.RunChartUSLColor = System.Drawing.Color.Red
        Me.RunChart10.Size = New System.Drawing.Size(598, 124)
        Me.RunChart10.TabIndex = 0
        '
        'Panel27
        '
        Me.Panel27.BackColor = System.Drawing.Color.OldLace
        Me.Panel27.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.Panel27.Controls.Add(Me.Label231)
        Me.Panel27.Controls.Add(Me.Label234)
        Me.Panel27.Controls.Add(Me.Label235)
        Me.Panel27.Controls.Add(Me.Label239)
        Me.Panel27.Controls.Add(Me.Label240)
        Me.Panel27.Controls.Add(Me.Label243)
        Me.Panel27.Controls.Add(Me.Label245)
        Me.Panel27.Controls.Add(Me.Label246)
        Me.Panel27.Controls.Add(Me.Label249)
        Me.Panel27.Controls.Add(Me.Label250)
        Me.Panel27.Controls.Add(Me.Label254)
        Me.Panel27.Controls.Add(Me.Label255)
        Me.Panel27.Controls.Add(Me.RunChart11)
        Me.Panel27.Location = New System.Drawing.Point(3, 144)
        Me.Panel27.Name = "Panel27"
        Me.Panel27.Size = New System.Drawing.Size(966, 135)
        Me.Panel27.TabIndex = 2
        Me.Panel27.Visible = False
        '
        'Label231
        '
        Me.Label231.BackColor = System.Drawing.Color.Transparent
        Me.Label231.Location = New System.Drawing.Point(797, 110)
        Me.Label231.Name = "Label231"
        Me.Label231.Size = New System.Drawing.Size(56, 16)
        Me.Label231.TabIndex = 45
        Me.Label231.Text = "LSL"
        Me.Label231.TextAlign = System.Drawing.ContentAlignment.MiddleLeft
        '
        'Label234
        '
        Me.Label234.BackColor = System.Drawing.Color.Transparent
        Me.Label234.Location = New System.Drawing.Point(797, 62)
        Me.Label234.Name = "Label234"
        Me.Label234.Size = New System.Drawing.Size(56, 16)
        Me.Label234.TabIndex = 43
        Me.Label234.Text = "NOM"
        Me.Label234.TextAlign = System.Drawing.ContentAlignment.MiddleLeft
        '
        'Label235
        '
        Me.Label235.BackColor = System.Drawing.Color.Transparent
        Me.Label235.Location = New System.Drawing.Point(797, 87)
        Me.Label235.Name = "Label235"
        Me.Label235.Size = New System.Drawing.Size(56, 16)
        Me.Label235.TabIndex = 44
        Me.Label235.Text = "LCL"
        Me.Label235.TextAlign = System.Drawing.ContentAlignment.MiddleLeft
        '
        'Label239
        '
        Me.Label239.BackColor = System.Drawing.Color.Transparent
        Me.Label239.Location = New System.Drawing.Point(797, 15)
        Me.Label239.Name = "Label239"
        Me.Label239.Size = New System.Drawing.Size(56, 16)
        Me.Label239.TabIndex = 41
        Me.Label239.Text = "USL"
        Me.Label239.TextAlign = System.Drawing.ContentAlignment.MiddleLeft
        '
        'Label240
        '
        Me.Label240.BackColor = System.Drawing.Color.Transparent
        Me.Label240.Location = New System.Drawing.Point(797, 39)
        Me.Label240.Name = "Label240"
        Me.Label240.Size = New System.Drawing.Size(56, 16)
        Me.Label240.TabIndex = 42
        Me.Label240.Text = "UCL"
        Me.Label240.TextAlign = System.Drawing.ContentAlignment.MiddleLeft
        '
        'Label243
        '
        Me.Label243.BackColor = System.Drawing.Color.Transparent
        Me.Label243.Location = New System.Drawing.Point(859, 108)
        Me.Label243.Name = "Label243"
        Me.Label243.Size = New System.Drawing.Size(93, 16)
        Me.Label243.TabIndex = 39
        Me.Label243.Text = "-0.5"
        Me.Label243.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'Label245
        '
        Me.Label245.BackColor = System.Drawing.Color.Transparent
        Me.Label245.Location = New System.Drawing.Point(859, 60)
        Me.Label245.Name = "Label245"
        Me.Label245.Size = New System.Drawing.Size(93, 16)
        Me.Label245.TabIndex = 35
        Me.Label245.Text = "1.5"
        Me.Label245.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'Label246
        '
        Me.Label246.BackColor = System.Drawing.Color.Transparent
        Me.Label246.Location = New System.Drawing.Point(859, 85)
        Me.Label246.Name = "Label246"
        Me.Label246.Size = New System.Drawing.Size(93, 16)
        Me.Label246.TabIndex = 36
        Me.Label246.Text = "-0.5"
        Me.Label246.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'Label249
        '
        Me.Label249.BackColor = System.Drawing.Color.Transparent
        Me.Label249.Location = New System.Drawing.Point(859, 12)
        Me.Label249.Name = "Label249"
        Me.Label249.Size = New System.Drawing.Size(93, 16)
        Me.Label249.TabIndex = 29
        Me.Label249.Text = "1.5"
        Me.Label249.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'Label250
        '
        Me.Label250.BackColor = System.Drawing.Color.Transparent
        Me.Label250.Location = New System.Drawing.Point(859, 37)
        Me.Label250.Name = "Label250"
        Me.Label250.Size = New System.Drawing.Size(93, 16)
        Me.Label250.TabIndex = 30
        Me.Label250.Text = "-0.5"
        Me.Label250.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'Label254
        '
        Me.Label254.BackColor = System.Drawing.Color.LightGray
        Me.Label254.Font = New System.Drawing.Font("Arial", 18.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label254.ForeColor = System.Drawing.Color.Black
        Me.Label254.Location = New System.Drawing.Point(7, 37)
        Me.Label254.Name = "Label254"
        Me.Label254.Size = New System.Drawing.Size(180, 55)
        Me.Label254.TabIndex = 34
        Me.Label254.Text = "+000.0000"
        Me.Label254.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'Label255
        '
        Me.Label255.Location = New System.Drawing.Point(3, 5)
        Me.Label255.Name = "Label255"
        Me.Label255.Size = New System.Drawing.Size(184, 23)
        Me.Label255.TabIndex = 4
        Me.Label255.Text = "Result 6"
        Me.Label255.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'RunChart11
        '
        Me.RunChart11.BackColor = System.Drawing.Color.Black
        Me.RunChart11.Clickable = True
        Me.RunChart11.ControlCause = 0.0!
        Me.RunChart11.Location = New System.Drawing.Point(193, 3)
        Me.RunChart11.Name = "RunChart11"
        Me.RunChart11.RunChartCurrentSampleCount = 50
        Me.RunChart11.RunChartLCL = -0.025!
        Me.RunChart11.RunChartLCLColor = System.Drawing.Color.Gold
        Me.RunChart11.RunChartLSL = -0.04!
        Me.RunChart11.RunChartLSLColor = System.Drawing.Color.Red
        Me.RunChart11.RunChartNominal = 0.0!
        Me.RunChart11.RunChartNominalColor = System.Drawing.Color.Lime
        Me.RunChart11.RunChartSamplesValue = 0.0!
        Me.RunChart11.RunChartTotalSampleCount = 50
        Me.RunChart11.RunChartUCL = 0.025!
        Me.RunChart11.RunChartUCLColor = System.Drawing.Color.Gold
        Me.RunChart11.RunChartUSL = 0.04!
        Me.RunChart11.RunChartUSLColor = System.Drawing.Color.Red
        Me.RunChart11.Size = New System.Drawing.Size(598, 124)
        Me.RunChart11.TabIndex = 0
        '
        'Panel28
        '
        Me.Panel28.BackColor = System.Drawing.Color.OldLace
        Me.Panel28.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.Panel28.Controls.Add(Me.Label218)
        Me.Panel28.Controls.Add(Me.Label221)
        Me.Panel28.Controls.Add(Me.Label222)
        Me.Panel28.Controls.Add(Me.Label226)
        Me.Panel28.Controls.Add(Me.Label227)
        Me.Panel28.Controls.Add(Me.Label256)
        Me.Panel28.Controls.Add(Me.Label258)
        Me.Panel28.Controls.Add(Me.Label259)
        Me.Panel28.Controls.Add(Me.Label262)
        Me.Panel28.Controls.Add(Me.Label263)
        Me.Panel28.Controls.Add(Me.Label267)
        Me.Panel28.Controls.Add(Me.Label268)
        Me.Panel28.Controls.Add(Me.RunChart12)
        Me.Panel28.Location = New System.Drawing.Point(3, 3)
        Me.Panel28.Name = "Panel28"
        Me.Panel28.Size = New System.Drawing.Size(966, 135)
        Me.Panel28.TabIndex = 1
        Me.Panel28.Visible = False
        '
        'Label218
        '
        Me.Label218.BackColor = System.Drawing.Color.Transparent
        Me.Label218.Location = New System.Drawing.Point(797, 108)
        Me.Label218.Name = "Label218"
        Me.Label218.Size = New System.Drawing.Size(56, 16)
        Me.Label218.TabIndex = 45
        Me.Label218.Text = "LSL"
        Me.Label218.TextAlign = System.Drawing.ContentAlignment.MiddleLeft
        '
        'Label221
        '
        Me.Label221.BackColor = System.Drawing.Color.Transparent
        Me.Label221.Location = New System.Drawing.Point(797, 60)
        Me.Label221.Name = "Label221"
        Me.Label221.Size = New System.Drawing.Size(56, 16)
        Me.Label221.TabIndex = 43
        Me.Label221.Text = "NOM"
        Me.Label221.TextAlign = System.Drawing.ContentAlignment.MiddleLeft
        '
        'Label222
        '
        Me.Label222.BackColor = System.Drawing.Color.Transparent
        Me.Label222.Location = New System.Drawing.Point(797, 85)
        Me.Label222.Name = "Label222"
        Me.Label222.Size = New System.Drawing.Size(56, 16)
        Me.Label222.TabIndex = 44
        Me.Label222.Text = "LCL"
        Me.Label222.TextAlign = System.Drawing.ContentAlignment.MiddleLeft
        '
        'Label226
        '
        Me.Label226.BackColor = System.Drawing.Color.Transparent
        Me.Label226.Location = New System.Drawing.Point(797, 13)
        Me.Label226.Name = "Label226"
        Me.Label226.Size = New System.Drawing.Size(56, 16)
        Me.Label226.TabIndex = 41
        Me.Label226.Text = "USL"
        Me.Label226.TextAlign = System.Drawing.ContentAlignment.MiddleLeft
        '
        'Label227
        '
        Me.Label227.BackColor = System.Drawing.Color.Transparent
        Me.Label227.Location = New System.Drawing.Point(797, 37)
        Me.Label227.Name = "Label227"
        Me.Label227.Size = New System.Drawing.Size(56, 16)
        Me.Label227.TabIndex = 42
        Me.Label227.Text = "UCL"
        Me.Label227.TextAlign = System.Drawing.ContentAlignment.MiddleLeft
        '
        'Label256
        '
        Me.Label256.BackColor = System.Drawing.Color.Transparent
        Me.Label256.Location = New System.Drawing.Point(859, 108)
        Me.Label256.Name = "Label256"
        Me.Label256.Size = New System.Drawing.Size(93, 16)
        Me.Label256.TabIndex = 39
        Me.Label256.Text = "-0.5"
        Me.Label256.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'Label258
        '
        Me.Label258.BackColor = System.Drawing.Color.Transparent
        Me.Label258.Location = New System.Drawing.Point(859, 60)
        Me.Label258.Name = "Label258"
        Me.Label258.Size = New System.Drawing.Size(93, 16)
        Me.Label258.TabIndex = 35
        Me.Label258.Text = "1.5"
        Me.Label258.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'Label259
        '
        Me.Label259.BackColor = System.Drawing.Color.Transparent
        Me.Label259.Location = New System.Drawing.Point(859, 85)
        Me.Label259.Name = "Label259"
        Me.Label259.Size = New System.Drawing.Size(93, 16)
        Me.Label259.TabIndex = 36
        Me.Label259.Text = "-0.5"
        Me.Label259.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'Label262
        '
        Me.Label262.BackColor = System.Drawing.Color.Transparent
        Me.Label262.Location = New System.Drawing.Point(859, 12)
        Me.Label262.Name = "Label262"
        Me.Label262.Size = New System.Drawing.Size(93, 16)
        Me.Label262.TabIndex = 29
        Me.Label262.Text = "1.5"
        Me.Label262.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'Label263
        '
        Me.Label263.BackColor = System.Drawing.Color.Transparent
        Me.Label263.Location = New System.Drawing.Point(859, 37)
        Me.Label263.Name = "Label263"
        Me.Label263.Size = New System.Drawing.Size(93, 16)
        Me.Label263.TabIndex = 30
        Me.Label263.Text = "-0.5"
        Me.Label263.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'Label267
        '
        Me.Label267.BackColor = System.Drawing.Color.LightGray
        Me.Label267.Font = New System.Drawing.Font("Arial", 18.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label267.ForeColor = System.Drawing.Color.Black
        Me.Label267.Location = New System.Drawing.Point(7, 37)
        Me.Label267.Name = "Label267"
        Me.Label267.Size = New System.Drawing.Size(180, 55)
        Me.Label267.TabIndex = 34
        Me.Label267.Text = "+000.0000"
        Me.Label267.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'Label268
        '
        Me.Label268.Location = New System.Drawing.Point(3, 5)
        Me.Label268.Name = "Label268"
        Me.Label268.Size = New System.Drawing.Size(184, 23)
        Me.Label268.TabIndex = 4
        Me.Label268.Text = "Result 5"
        Me.Label268.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'RunChart12
        '
        Me.RunChart12.BackColor = System.Drawing.Color.Black
        Me.RunChart12.Clickable = True
        Me.RunChart12.ControlCause = 0.0!
        Me.RunChart12.Location = New System.Drawing.Point(193, 6)
        Me.RunChart12.Name = "RunChart12"
        Me.RunChart12.RunChartCurrentSampleCount = 50
        Me.RunChart12.RunChartLCL = -0.025!
        Me.RunChart12.RunChartLCLColor = System.Drawing.Color.Gold
        Me.RunChart12.RunChartLSL = -0.04!
        Me.RunChart12.RunChartLSLColor = System.Drawing.Color.Red
        Me.RunChart12.RunChartNominal = 0.0!
        Me.RunChart12.RunChartNominalColor = System.Drawing.Color.Lime
        Me.RunChart12.RunChartSamplesValue = 0.0!
        Me.RunChart12.RunChartTotalSampleCount = 50
        Me.RunChart12.RunChartUCL = 0.025!
        Me.RunChart12.RunChartUCLColor = System.Drawing.Color.Gold
        Me.RunChart12.RunChartUSL = 0.04!
        Me.RunChart12.RunChartUSLColor = System.Drawing.Color.Red
        Me.RunChart12.Size = New System.Drawing.Size(598, 124)
        Me.RunChart12.TabIndex = 0
        '
        'TableLayoutPanel5
        '
        Me.TableLayoutPanel5.ColumnCount = 1
        Me.TableLayoutPanel5.ColumnStyles.Add(New System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 100.0!))
        Me.TableLayoutPanel5.Controls.Add(Me.Panel21, 0, 3)
        Me.TableLayoutPanel5.Controls.Add(Me.Panel22, 0, 2)
        Me.TableLayoutPanel5.Controls.Add(Me.Panel23, 0, 1)
        Me.TableLayoutPanel5.Controls.Add(Me.Panel24, 0, 0)
        Me.TableLayoutPanel5.Location = New System.Drawing.Point(7, 6)
        Me.TableLayoutPanel5.Name = "TableLayoutPanel5"
        Me.TableLayoutPanel5.RowCount = 4
        Me.TableLayoutPanel5.RowStyles.Add(New System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 25.0!))
        Me.TableLayoutPanel5.RowStyles.Add(New System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 25.0!))
        Me.TableLayoutPanel5.RowStyles.Add(New System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 25.0!))
        Me.TableLayoutPanel5.RowStyles.Add(New System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 25.0!))
        Me.TableLayoutPanel5.RowStyles.Add(New System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 20.0!))
        Me.TableLayoutPanel5.RowStyles.Add(New System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 20.0!))
        Me.TableLayoutPanel5.RowStyles.Add(New System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 20.0!))
        Me.TableLayoutPanel5.RowStyles.Add(New System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 20.0!))
        Me.TableLayoutPanel5.Size = New System.Drawing.Size(972, 564)
        Me.TableLayoutPanel5.TabIndex = 2
        '
        'Panel21
        '
        Me.Panel21.Controls.Add(Me.Label165)
        Me.Panel21.Controls.Add(Me.Label166)
        Me.Panel21.Controls.Add(Me.Label167)
        Me.Panel21.Controls.Add(Me.Label168)
        Me.Panel21.Controls.Add(Me.Label169)
        Me.Panel21.Controls.Add(Me.Label170)
        Me.Panel21.Controls.Add(Me.Label171)
        Me.Panel21.Controls.Add(Me.Label172)
        Me.Panel21.Controls.Add(Me.Label173)
        Me.Panel21.Controls.Add(Me.Label174)
        Me.Panel21.Controls.Add(Me.Label175)
        Me.Panel21.Controls.Add(Me.Label176)
        Me.Panel21.Controls.Add(Me.Label177)
        Me.Panel21.Location = New System.Drawing.Point(3, 426)
        Me.Panel21.Name = "Panel21"
        Me.Panel21.Size = New System.Drawing.Size(966, 135)
        Me.Panel21.TabIndex = 4
        '
        'Label165
        '
        Me.Label165.BackColor = System.Drawing.Color.WhiteSmoke
        Me.Label165.Location = New System.Drawing.Point(859, 108)
        Me.Label165.Name = "Label165"
        Me.Label165.Size = New System.Drawing.Size(93, 16)
        Me.Label165.TabIndex = 39
        Me.Label165.Text = "-0.5"
        Me.Label165.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'Label166
        '
        Me.Label166.BackColor = System.Drawing.Color.WhiteSmoke
        Me.Label166.Location = New System.Drawing.Point(814, 108)
        Me.Label166.Name = "Label166"
        Me.Label166.Size = New System.Drawing.Size(39, 23)
        Me.Label166.TabIndex = 40
        Me.Label166.Text = "LSL"
        '
        'Label167
        '
        Me.Label167.BackColor = System.Drawing.Color.WhiteSmoke
        Me.Label167.Location = New System.Drawing.Point(859, 60)
        Me.Label167.Name = "Label167"
        Me.Label167.Size = New System.Drawing.Size(93, 16)
        Me.Label167.TabIndex = 35
        Me.Label167.Text = "1.5"
        Me.Label167.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'Label168
        '
        Me.Label168.BackColor = System.Drawing.Color.WhiteSmoke
        Me.Label168.Location = New System.Drawing.Point(859, 85)
        Me.Label168.Name = "Label168"
        Me.Label168.Size = New System.Drawing.Size(93, 16)
        Me.Label168.TabIndex = 36
        Me.Label168.Text = "-0.5"
        Me.Label168.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'Label169
        '
        Me.Label169.BackColor = System.Drawing.Color.WhiteSmoke
        Me.Label169.Location = New System.Drawing.Point(797, 60)
        Me.Label169.Name = "Label169"
        Me.Label169.Size = New System.Drawing.Size(56, 16)
        Me.Label169.TabIndex = 37
        Me.Label169.Text = "USL"
        Me.Label169.TextAlign = System.Drawing.ContentAlignment.TopRight
        '
        'Label170
        '
        Me.Label170.BackColor = System.Drawing.Color.WhiteSmoke
        Me.Label170.Location = New System.Drawing.Point(814, 85)
        Me.Label170.Name = "Label170"
        Me.Label170.Size = New System.Drawing.Size(39, 23)
        Me.Label170.TabIndex = 38
        Me.Label170.Text = "LSL"
        '
        'Label171
        '
        Me.Label171.BackColor = System.Drawing.Color.WhiteSmoke
        Me.Label171.Location = New System.Drawing.Point(859, 12)
        Me.Label171.Name = "Label171"
        Me.Label171.Size = New System.Drawing.Size(93, 16)
        Me.Label171.TabIndex = 29
        Me.Label171.Text = "1.5"
        Me.Label171.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'Label172
        '
        Me.Label172.BackColor = System.Drawing.Color.WhiteSmoke
        Me.Label172.Location = New System.Drawing.Point(859, 37)
        Me.Label172.Name = "Label172"
        Me.Label172.Size = New System.Drawing.Size(93, 16)
        Me.Label172.TabIndex = 30
        Me.Label172.Text = "-0.5"
        Me.Label172.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'Label173
        '
        Me.Label173.BackColor = System.Drawing.Color.WhiteSmoke
        Me.Label173.Location = New System.Drawing.Point(26, 104)
        Me.Label173.Name = "Label173"
        Me.Label173.Size = New System.Drawing.Size(65, 20)
        Me.Label173.TabIndex = 31
        Me.Label173.Text = "mm"
        Me.Label173.TextAlign = System.Drawing.ContentAlignment.TopCenter
        '
        'Label174
        '
        Me.Label174.BackColor = System.Drawing.Color.WhiteSmoke
        Me.Label174.Location = New System.Drawing.Point(797, 12)
        Me.Label174.Name = "Label174"
        Me.Label174.Size = New System.Drawing.Size(56, 16)
        Me.Label174.TabIndex = 32
        Me.Label174.Text = "USL"
        Me.Label174.TextAlign = System.Drawing.ContentAlignment.TopRight
        '
        'Label175
        '
        Me.Label175.BackColor = System.Drawing.Color.WhiteSmoke
        Me.Label175.Location = New System.Drawing.Point(814, 37)
        Me.Label175.Name = "Label175"
        Me.Label175.Size = New System.Drawing.Size(39, 23)
        Me.Label175.TabIndex = 33
        Me.Label175.Text = "LSL"
        '
        'Label176
        '
        Me.Label176.Font = New System.Drawing.Font("Tahoma", 27.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label176.ForeColor = System.Drawing.Color.ForestGreen
        Me.Label176.Location = New System.Drawing.Point(7, 37)
        Me.Label176.Name = "Label176"
        Me.Label176.Size = New System.Drawing.Size(180, 55)
        Me.Label176.TabIndex = 34
        Me.Label176.Text = "000.0000"
        Me.Label176.TextAlign = System.Drawing.ContentAlignment.TopCenter
        '
        'Label177
        '
        Me.Label177.Location = New System.Drawing.Point(3, 5)
        Me.Label177.Name = "Label177"
        Me.Label177.Size = New System.Drawing.Size(88, 23)
        Me.Label177.TabIndex = 4
        Me.Label177.Text = "Result 1"
        '
        'Panel22
        '
        Me.Panel22.Controls.Add(Me.Label178)
        Me.Panel22.Controls.Add(Me.Label179)
        Me.Panel22.Controls.Add(Me.Label180)
        Me.Panel22.Controls.Add(Me.Label181)
        Me.Panel22.Controls.Add(Me.Label182)
        Me.Panel22.Controls.Add(Me.Label183)
        Me.Panel22.Controls.Add(Me.Label184)
        Me.Panel22.Controls.Add(Me.Label185)
        Me.Panel22.Controls.Add(Me.Label186)
        Me.Panel22.Controls.Add(Me.Label187)
        Me.Panel22.Controls.Add(Me.Label188)
        Me.Panel22.Controls.Add(Me.Label189)
        Me.Panel22.Controls.Add(Me.Label190)
        Me.Panel22.Location = New System.Drawing.Point(3, 285)
        Me.Panel22.Name = "Panel22"
        Me.Panel22.Size = New System.Drawing.Size(966, 135)
        Me.Panel22.TabIndex = 3
        '
        'Label178
        '
        Me.Label178.BackColor = System.Drawing.Color.WhiteSmoke
        Me.Label178.Location = New System.Drawing.Point(859, 108)
        Me.Label178.Name = "Label178"
        Me.Label178.Size = New System.Drawing.Size(93, 16)
        Me.Label178.TabIndex = 39
        Me.Label178.Text = "-0.5"
        Me.Label178.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'Label179
        '
        Me.Label179.BackColor = System.Drawing.Color.WhiteSmoke
        Me.Label179.Location = New System.Drawing.Point(814, 108)
        Me.Label179.Name = "Label179"
        Me.Label179.Size = New System.Drawing.Size(39, 23)
        Me.Label179.TabIndex = 40
        Me.Label179.Text = "LSL"
        '
        'Label180
        '
        Me.Label180.BackColor = System.Drawing.Color.WhiteSmoke
        Me.Label180.Location = New System.Drawing.Point(859, 60)
        Me.Label180.Name = "Label180"
        Me.Label180.Size = New System.Drawing.Size(93, 16)
        Me.Label180.TabIndex = 35
        Me.Label180.Text = "1.5"
        Me.Label180.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'Label181
        '
        Me.Label181.BackColor = System.Drawing.Color.WhiteSmoke
        Me.Label181.Location = New System.Drawing.Point(859, 85)
        Me.Label181.Name = "Label181"
        Me.Label181.Size = New System.Drawing.Size(93, 16)
        Me.Label181.TabIndex = 36
        Me.Label181.Text = "-0.5"
        Me.Label181.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'Label182
        '
        Me.Label182.BackColor = System.Drawing.Color.WhiteSmoke
        Me.Label182.Location = New System.Drawing.Point(797, 60)
        Me.Label182.Name = "Label182"
        Me.Label182.Size = New System.Drawing.Size(56, 16)
        Me.Label182.TabIndex = 37
        Me.Label182.Text = "USL"
        Me.Label182.TextAlign = System.Drawing.ContentAlignment.TopRight
        '
        'Label183
        '
        Me.Label183.BackColor = System.Drawing.Color.WhiteSmoke
        Me.Label183.Location = New System.Drawing.Point(814, 85)
        Me.Label183.Name = "Label183"
        Me.Label183.Size = New System.Drawing.Size(39, 23)
        Me.Label183.TabIndex = 38
        Me.Label183.Text = "LSL"
        '
        'Label184
        '
        Me.Label184.BackColor = System.Drawing.Color.WhiteSmoke
        Me.Label184.Location = New System.Drawing.Point(859, 12)
        Me.Label184.Name = "Label184"
        Me.Label184.Size = New System.Drawing.Size(93, 16)
        Me.Label184.TabIndex = 29
        Me.Label184.Text = "1.5"
        Me.Label184.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'Label185
        '
        Me.Label185.BackColor = System.Drawing.Color.WhiteSmoke
        Me.Label185.Location = New System.Drawing.Point(859, 37)
        Me.Label185.Name = "Label185"
        Me.Label185.Size = New System.Drawing.Size(93, 16)
        Me.Label185.TabIndex = 30
        Me.Label185.Text = "-0.5"
        Me.Label185.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'Label186
        '
        Me.Label186.BackColor = System.Drawing.Color.WhiteSmoke
        Me.Label186.Location = New System.Drawing.Point(26, 104)
        Me.Label186.Name = "Label186"
        Me.Label186.Size = New System.Drawing.Size(65, 20)
        Me.Label186.TabIndex = 31
        Me.Label186.Text = "mm"
        Me.Label186.TextAlign = System.Drawing.ContentAlignment.TopCenter
        '
        'Label187
        '
        Me.Label187.BackColor = System.Drawing.Color.WhiteSmoke
        Me.Label187.Location = New System.Drawing.Point(797, 12)
        Me.Label187.Name = "Label187"
        Me.Label187.Size = New System.Drawing.Size(56, 16)
        Me.Label187.TabIndex = 32
        Me.Label187.Text = "USL"
        Me.Label187.TextAlign = System.Drawing.ContentAlignment.TopRight
        '
        'Label188
        '
        Me.Label188.BackColor = System.Drawing.Color.WhiteSmoke
        Me.Label188.Location = New System.Drawing.Point(814, 37)
        Me.Label188.Name = "Label188"
        Me.Label188.Size = New System.Drawing.Size(39, 23)
        Me.Label188.TabIndex = 33
        Me.Label188.Text = "LSL"
        '
        'Label189
        '
        Me.Label189.Font = New System.Drawing.Font("Tahoma", 27.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label189.ForeColor = System.Drawing.Color.ForestGreen
        Me.Label189.Location = New System.Drawing.Point(7, 37)
        Me.Label189.Name = "Label189"
        Me.Label189.Size = New System.Drawing.Size(180, 55)
        Me.Label189.TabIndex = 34
        Me.Label189.Text = "000.0000"
        Me.Label189.TextAlign = System.Drawing.ContentAlignment.TopCenter
        '
        'Label190
        '
        Me.Label190.Location = New System.Drawing.Point(3, 5)
        Me.Label190.Name = "Label190"
        Me.Label190.Size = New System.Drawing.Size(88, 23)
        Me.Label190.TabIndex = 4
        Me.Label190.Text = "Result 1"
        '
        'Panel23
        '
        Me.Panel23.Controls.Add(Me.Label191)
        Me.Panel23.Controls.Add(Me.Label192)
        Me.Panel23.Controls.Add(Me.Label193)
        Me.Panel23.Controls.Add(Me.Label194)
        Me.Panel23.Controls.Add(Me.Label195)
        Me.Panel23.Controls.Add(Me.Label196)
        Me.Panel23.Controls.Add(Me.Label197)
        Me.Panel23.Controls.Add(Me.Label198)
        Me.Panel23.Controls.Add(Me.Label199)
        Me.Panel23.Controls.Add(Me.Label200)
        Me.Panel23.Controls.Add(Me.Label201)
        Me.Panel23.Controls.Add(Me.Label202)
        Me.Panel23.Controls.Add(Me.Label203)
        Me.Panel23.Location = New System.Drawing.Point(3, 144)
        Me.Panel23.Name = "Panel23"
        Me.Panel23.Size = New System.Drawing.Size(966, 135)
        Me.Panel23.TabIndex = 2
        '
        'Label191
        '
        Me.Label191.BackColor = System.Drawing.Color.WhiteSmoke
        Me.Label191.Location = New System.Drawing.Point(859, 108)
        Me.Label191.Name = "Label191"
        Me.Label191.Size = New System.Drawing.Size(93, 16)
        Me.Label191.TabIndex = 39
        Me.Label191.Text = "-0.5"
        Me.Label191.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'Label192
        '
        Me.Label192.BackColor = System.Drawing.Color.WhiteSmoke
        Me.Label192.Location = New System.Drawing.Point(814, 108)
        Me.Label192.Name = "Label192"
        Me.Label192.Size = New System.Drawing.Size(39, 23)
        Me.Label192.TabIndex = 40
        Me.Label192.Text = "LSL"
        '
        'Label193
        '
        Me.Label193.BackColor = System.Drawing.Color.WhiteSmoke
        Me.Label193.Location = New System.Drawing.Point(859, 60)
        Me.Label193.Name = "Label193"
        Me.Label193.Size = New System.Drawing.Size(93, 16)
        Me.Label193.TabIndex = 35
        Me.Label193.Text = "1.5"
        Me.Label193.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'Label194
        '
        Me.Label194.BackColor = System.Drawing.Color.WhiteSmoke
        Me.Label194.Location = New System.Drawing.Point(859, 85)
        Me.Label194.Name = "Label194"
        Me.Label194.Size = New System.Drawing.Size(93, 16)
        Me.Label194.TabIndex = 36
        Me.Label194.Text = "-0.5"
        Me.Label194.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'Label195
        '
        Me.Label195.BackColor = System.Drawing.Color.WhiteSmoke
        Me.Label195.Location = New System.Drawing.Point(797, 60)
        Me.Label195.Name = "Label195"
        Me.Label195.Size = New System.Drawing.Size(56, 16)
        Me.Label195.TabIndex = 37
        Me.Label195.Text = "USL"
        Me.Label195.TextAlign = System.Drawing.ContentAlignment.TopRight
        '
        'Label196
        '
        Me.Label196.BackColor = System.Drawing.Color.WhiteSmoke
        Me.Label196.Location = New System.Drawing.Point(814, 85)
        Me.Label196.Name = "Label196"
        Me.Label196.Size = New System.Drawing.Size(39, 23)
        Me.Label196.TabIndex = 38
        Me.Label196.Text = "LSL"
        '
        'Label197
        '
        Me.Label197.BackColor = System.Drawing.Color.WhiteSmoke
        Me.Label197.Location = New System.Drawing.Point(859, 12)
        Me.Label197.Name = "Label197"
        Me.Label197.Size = New System.Drawing.Size(93, 16)
        Me.Label197.TabIndex = 29
        Me.Label197.Text = "1.5"
        Me.Label197.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'Label198
        '
        Me.Label198.BackColor = System.Drawing.Color.WhiteSmoke
        Me.Label198.Location = New System.Drawing.Point(859, 37)
        Me.Label198.Name = "Label198"
        Me.Label198.Size = New System.Drawing.Size(93, 16)
        Me.Label198.TabIndex = 30
        Me.Label198.Text = "-0.5"
        Me.Label198.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'Label199
        '
        Me.Label199.BackColor = System.Drawing.Color.WhiteSmoke
        Me.Label199.Location = New System.Drawing.Point(26, 104)
        Me.Label199.Name = "Label199"
        Me.Label199.Size = New System.Drawing.Size(65, 20)
        Me.Label199.TabIndex = 31
        Me.Label199.Text = "mm"
        Me.Label199.TextAlign = System.Drawing.ContentAlignment.TopCenter
        '
        'Label200
        '
        Me.Label200.BackColor = System.Drawing.Color.WhiteSmoke
        Me.Label200.Location = New System.Drawing.Point(797, 12)
        Me.Label200.Name = "Label200"
        Me.Label200.Size = New System.Drawing.Size(56, 16)
        Me.Label200.TabIndex = 32
        Me.Label200.Text = "USL"
        Me.Label200.TextAlign = System.Drawing.ContentAlignment.TopRight
        '
        'Label201
        '
        Me.Label201.BackColor = System.Drawing.Color.WhiteSmoke
        Me.Label201.Location = New System.Drawing.Point(814, 37)
        Me.Label201.Name = "Label201"
        Me.Label201.Size = New System.Drawing.Size(39, 23)
        Me.Label201.TabIndex = 33
        Me.Label201.Text = "LSL"
        '
        'Label202
        '
        Me.Label202.Font = New System.Drawing.Font("Tahoma", 27.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label202.ForeColor = System.Drawing.Color.ForestGreen
        Me.Label202.Location = New System.Drawing.Point(7, 37)
        Me.Label202.Name = "Label202"
        Me.Label202.Size = New System.Drawing.Size(180, 55)
        Me.Label202.TabIndex = 34
        Me.Label202.Text = "000.0000"
        Me.Label202.TextAlign = System.Drawing.ContentAlignment.TopCenter
        '
        'Label203
        '
        Me.Label203.Location = New System.Drawing.Point(3, 5)
        Me.Label203.Name = "Label203"
        Me.Label203.Size = New System.Drawing.Size(88, 23)
        Me.Label203.TabIndex = 4
        Me.Label203.Text = "Result 1"
        '
        'Panel24
        '
        Me.Panel24.Controls.Add(Me.Label204)
        Me.Panel24.Controls.Add(Me.Label205)
        Me.Panel24.Controls.Add(Me.Label206)
        Me.Panel24.Controls.Add(Me.Label207)
        Me.Panel24.Controls.Add(Me.Label208)
        Me.Panel24.Controls.Add(Me.Label209)
        Me.Panel24.Controls.Add(Me.Label210)
        Me.Panel24.Controls.Add(Me.Label211)
        Me.Panel24.Controls.Add(Me.Label212)
        Me.Panel24.Controls.Add(Me.Label213)
        Me.Panel24.Controls.Add(Me.Label214)
        Me.Panel24.Controls.Add(Me.Label215)
        Me.Panel24.Controls.Add(Me.Label216)
        Me.Panel24.Location = New System.Drawing.Point(3, 3)
        Me.Panel24.Name = "Panel24"
        Me.Panel24.Size = New System.Drawing.Size(966, 135)
        Me.Panel24.TabIndex = 1
        '
        'Label204
        '
        Me.Label204.BackColor = System.Drawing.Color.WhiteSmoke
        Me.Label204.Location = New System.Drawing.Point(859, 108)
        Me.Label204.Name = "Label204"
        Me.Label204.Size = New System.Drawing.Size(93, 16)
        Me.Label204.TabIndex = 39
        Me.Label204.Text = "-0.5"
        Me.Label204.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'Label205
        '
        Me.Label205.BackColor = System.Drawing.Color.WhiteSmoke
        Me.Label205.Location = New System.Drawing.Point(814, 108)
        Me.Label205.Name = "Label205"
        Me.Label205.Size = New System.Drawing.Size(39, 23)
        Me.Label205.TabIndex = 40
        Me.Label205.Text = "LSL"
        '
        'Label206
        '
        Me.Label206.BackColor = System.Drawing.Color.WhiteSmoke
        Me.Label206.Location = New System.Drawing.Point(859, 60)
        Me.Label206.Name = "Label206"
        Me.Label206.Size = New System.Drawing.Size(93, 16)
        Me.Label206.TabIndex = 35
        Me.Label206.Text = "1.5"
        Me.Label206.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'Label207
        '
        Me.Label207.BackColor = System.Drawing.Color.WhiteSmoke
        Me.Label207.Location = New System.Drawing.Point(859, 85)
        Me.Label207.Name = "Label207"
        Me.Label207.Size = New System.Drawing.Size(93, 16)
        Me.Label207.TabIndex = 36
        Me.Label207.Text = "-0.5"
        Me.Label207.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'Label208
        '
        Me.Label208.BackColor = System.Drawing.Color.WhiteSmoke
        Me.Label208.Location = New System.Drawing.Point(797, 60)
        Me.Label208.Name = "Label208"
        Me.Label208.Size = New System.Drawing.Size(56, 16)
        Me.Label208.TabIndex = 37
        Me.Label208.Text = "USL"
        Me.Label208.TextAlign = System.Drawing.ContentAlignment.TopRight
        '
        'Label209
        '
        Me.Label209.BackColor = System.Drawing.Color.WhiteSmoke
        Me.Label209.Location = New System.Drawing.Point(814, 85)
        Me.Label209.Name = "Label209"
        Me.Label209.Size = New System.Drawing.Size(39, 23)
        Me.Label209.TabIndex = 38
        Me.Label209.Text = "LSL"
        '
        'Label210
        '
        Me.Label210.BackColor = System.Drawing.Color.WhiteSmoke
        Me.Label210.Location = New System.Drawing.Point(859, 12)
        Me.Label210.Name = "Label210"
        Me.Label210.Size = New System.Drawing.Size(93, 16)
        Me.Label210.TabIndex = 29
        Me.Label210.Text = "1.5"
        Me.Label210.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'Label211
        '
        Me.Label211.BackColor = System.Drawing.Color.WhiteSmoke
        Me.Label211.Location = New System.Drawing.Point(859, 37)
        Me.Label211.Name = "Label211"
        Me.Label211.Size = New System.Drawing.Size(93, 16)
        Me.Label211.TabIndex = 30
        Me.Label211.Text = "-0.5"
        Me.Label211.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'Label212
        '
        Me.Label212.BackColor = System.Drawing.Color.WhiteSmoke
        Me.Label212.Location = New System.Drawing.Point(26, 104)
        Me.Label212.Name = "Label212"
        Me.Label212.Size = New System.Drawing.Size(65, 20)
        Me.Label212.TabIndex = 31
        Me.Label212.Text = "mm"
        Me.Label212.TextAlign = System.Drawing.ContentAlignment.TopCenter
        '
        'Label213
        '
        Me.Label213.BackColor = System.Drawing.Color.WhiteSmoke
        Me.Label213.Location = New System.Drawing.Point(797, 12)
        Me.Label213.Name = "Label213"
        Me.Label213.Size = New System.Drawing.Size(56, 16)
        Me.Label213.TabIndex = 32
        Me.Label213.Text = "USL"
        Me.Label213.TextAlign = System.Drawing.ContentAlignment.TopRight
        '
        'Label214
        '
        Me.Label214.BackColor = System.Drawing.Color.WhiteSmoke
        Me.Label214.Location = New System.Drawing.Point(814, 37)
        Me.Label214.Name = "Label214"
        Me.Label214.Size = New System.Drawing.Size(39, 23)
        Me.Label214.TabIndex = 33
        Me.Label214.Text = "LSL"
        '
        'Label215
        '
        Me.Label215.Font = New System.Drawing.Font("Tahoma", 27.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label215.ForeColor = System.Drawing.Color.ForestGreen
        Me.Label215.Location = New System.Drawing.Point(7, 37)
        Me.Label215.Name = "Label215"
        Me.Label215.Size = New System.Drawing.Size(180, 55)
        Me.Label215.TabIndex = 34
        Me.Label215.Text = "000.0000"
        Me.Label215.TextAlign = System.Drawing.ContentAlignment.TopCenter
        '
        'Label216
        '
        Me.Label216.Location = New System.Drawing.Point(3, 5)
        Me.Label216.Name = "Label216"
        Me.Label216.Size = New System.Drawing.Size(88, 23)
        Me.Label216.TabIndex = 4
        Me.Label216.Text = "Result 1"
        '
        'TableLayoutPanel2
        '
        Me.TableLayoutPanel2.ColumnCount = 2
        Me.TableLayoutPanel2.ColumnStyles.Add(New System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 50.0!))
        Me.TableLayoutPanel2.ColumnStyles.Add(New System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 50.0!))
        Me.TableLayoutPanel2.Controls.Add(Me.Panel29, 0, 3)
        Me.TableLayoutPanel2.Controls.Add(Me.Panel30, 0, 3)
        Me.TableLayoutPanel2.Location = New System.Drawing.Point(0, 0)
        Me.TableLayoutPanel2.Name = "TableLayoutPanel2"
        Me.TableLayoutPanel2.RowCount = 4
        Me.TableLayoutPanel2.RowStyles.Add(New System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 20.0!))
        Me.TableLayoutPanel2.RowStyles.Add(New System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 20.0!))
        Me.TableLayoutPanel2.RowStyles.Add(New System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 20.0!))
        Me.TableLayoutPanel2.RowStyles.Add(New System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 20.0!))
        Me.TableLayoutPanel2.Size = New System.Drawing.Size(200, 100)
        Me.TableLayoutPanel2.TabIndex = 0
        '
        'Panel29
        '
        Me.Panel29.BackColor = System.Drawing.Color.WhiteSmoke
        Me.Panel29.Controls.Add(Me.Label269)
        Me.Panel29.Controls.Add(Me.Label270)
        Me.Panel29.Controls.Add(Me.Label271)
        Me.Panel29.Controls.Add(Me.Label272)
        Me.Panel29.Controls.Add(Me.Label273)
        Me.Panel29.Controls.Add(Me.Label274)
        Me.Panel29.Controls.Add(Me.Label275)
        Me.Panel29.Location = New System.Drawing.Point(103, 63)
        Me.Panel29.Name = "Panel29"
        Me.Panel29.Size = New System.Drawing.Size(94, 34)
        Me.Panel29.TabIndex = 24
        '
        'Label269
        '
        Me.Label269.BackColor = System.Drawing.Color.WhiteSmoke
        Me.Label269.Location = New System.Drawing.Point(350, 9)
        Me.Label269.Name = "Label269"
        Me.Label269.Size = New System.Drawing.Size(93, 16)
        Me.Label269.TabIndex = 0
        Me.Label269.Text = "1.5"
        Me.Label269.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'Label270
        '
        Me.Label270.BackColor = System.Drawing.Color.WhiteSmoke
        Me.Label270.Location = New System.Drawing.Point(350, 34)
        Me.Label270.Name = "Label270"
        Me.Label270.Size = New System.Drawing.Size(93, 16)
        Me.Label270.TabIndex = 1
        Me.Label270.Text = "-0.5"
        Me.Label270.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'Label271
        '
        Me.Label271.Location = New System.Drawing.Point(5, 9)
        Me.Label271.Name = "Label271"
        Me.Label271.Size = New System.Drawing.Size(189, 23)
        Me.Label271.TabIndex = 2
        Me.Label271.Text = "Result 4"
        '
        'Label272
        '
        Me.Label272.BackColor = System.Drawing.Color.WhiteSmoke
        Me.Label272.Location = New System.Drawing.Point(95, 101)
        Me.Label272.Name = "Label272"
        Me.Label272.Size = New System.Drawing.Size(65, 20)
        Me.Label272.TabIndex = 3
        Me.Label272.Text = "mm"
        Me.Label272.TextAlign = System.Drawing.ContentAlignment.TopCenter
        '
        'Label273
        '
        Me.Label273.BackColor = System.Drawing.Color.WhiteSmoke
        Me.Label273.Location = New System.Drawing.Point(288, 9)
        Me.Label273.Name = "Label273"
        Me.Label273.Size = New System.Drawing.Size(56, 16)
        Me.Label273.TabIndex = 26
        Me.Label273.Text = "USL"
        Me.Label273.TextAlign = System.Drawing.ContentAlignment.TopRight
        '
        'Label274
        '
        Me.Label274.BackColor = System.Drawing.Color.WhiteSmoke
        Me.Label274.Location = New System.Drawing.Point(305, 34)
        Me.Label274.Name = "Label274"
        Me.Label274.Size = New System.Drawing.Size(39, 23)
        Me.Label274.TabIndex = 27
        Me.Label274.Text = "LSL"
        '
        'Label275
        '
        Me.Label275.Font = New System.Drawing.Font("Tahoma", 36.0!)
        Me.Label275.ForeColor = System.Drawing.Color.ForestGreen
        Me.Label275.Location = New System.Drawing.Point(21, 34)
        Me.Label275.Name = "Label275"
        Me.Label275.Size = New System.Drawing.Size(224, 55)
        Me.Label275.TabIndex = 28
        Me.Label275.Text = "000.0000"
        Me.Label275.TextAlign = System.Drawing.ContentAlignment.TopCenter
        '
        'Panel30
        '
        Me.Panel30.BackColor = System.Drawing.Color.WhiteSmoke
        Me.Panel30.Controls.Add(Me.Label276)
        Me.Panel30.Controls.Add(Me.Label277)
        Me.Panel30.Controls.Add(Me.Label278)
        Me.Panel30.Controls.Add(Me.Label279)
        Me.Panel30.Controls.Add(Me.Label280)
        Me.Panel30.Controls.Add(Me.Label281)
        Me.Panel30.Controls.Add(Me.Label282)
        Me.Panel30.Location = New System.Drawing.Point(3, 63)
        Me.Panel30.Name = "Panel30"
        Me.Panel30.Size = New System.Drawing.Size(94, 34)
        Me.Panel30.TabIndex = 23
        '
        'Label276
        '
        Me.Label276.BackColor = System.Drawing.Color.WhiteSmoke
        Me.Label276.Location = New System.Drawing.Point(350, 9)
        Me.Label276.Name = "Label276"
        Me.Label276.Size = New System.Drawing.Size(93, 16)
        Me.Label276.TabIndex = 0
        Me.Label276.Text = "1.5"
        Me.Label276.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'Label277
        '
        Me.Label277.BackColor = System.Drawing.Color.WhiteSmoke
        Me.Label277.Location = New System.Drawing.Point(350, 34)
        Me.Label277.Name = "Label277"
        Me.Label277.Size = New System.Drawing.Size(93, 16)
        Me.Label277.TabIndex = 1
        Me.Label277.Text = "-0.5"
        Me.Label277.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'Label278
        '
        Me.Label278.Location = New System.Drawing.Point(5, 9)
        Me.Label278.Name = "Label278"
        Me.Label278.Size = New System.Drawing.Size(189, 23)
        Me.Label278.TabIndex = 2
        Me.Label278.Text = "Result 8"
        '
        'Label279
        '
        Me.Label279.BackColor = System.Drawing.Color.WhiteSmoke
        Me.Label279.Location = New System.Drawing.Point(95, 101)
        Me.Label279.Name = "Label279"
        Me.Label279.Size = New System.Drawing.Size(65, 20)
        Me.Label279.TabIndex = 3
        Me.Label279.Text = "mm"
        Me.Label279.TextAlign = System.Drawing.ContentAlignment.TopCenter
        '
        'Label280
        '
        Me.Label280.BackColor = System.Drawing.Color.WhiteSmoke
        Me.Label280.Location = New System.Drawing.Point(288, 9)
        Me.Label280.Name = "Label280"
        Me.Label280.Size = New System.Drawing.Size(56, 16)
        Me.Label280.TabIndex = 26
        Me.Label280.Text = "USL"
        Me.Label280.TextAlign = System.Drawing.ContentAlignment.TopRight
        '
        'Label281
        '
        Me.Label281.BackColor = System.Drawing.Color.WhiteSmoke
        Me.Label281.Location = New System.Drawing.Point(305, 34)
        Me.Label281.Name = "Label281"
        Me.Label281.Size = New System.Drawing.Size(39, 23)
        Me.Label281.TabIndex = 27
        Me.Label281.Text = "LSL"
        '
        'Label282
        '
        Me.Label282.Font = New System.Drawing.Font("Tahoma", 36.0!)
        Me.Label282.ForeColor = System.Drawing.Color.ForestGreen
        Me.Label282.Location = New System.Drawing.Point(21, 34)
        Me.Label282.Name = "Label282"
        Me.Label282.Size = New System.Drawing.Size(224, 55)
        Me.Label282.TabIndex = 28
        Me.Label282.Text = "000.0000"
        Me.Label282.TextAlign = System.Drawing.ContentAlignment.TopCenter
        '
        'Panel31
        '
        Me.Panel31.BackColor = System.Drawing.Color.WhiteSmoke
        Me.Panel31.Controls.Add(Me.Label283)
        Me.Panel31.Controls.Add(Me.Label284)
        Me.Panel31.Controls.Add(Me.Label285)
        Me.Panel31.Controls.Add(Me.Label286)
        Me.Panel31.Controls.Add(Me.Label287)
        Me.Panel31.Controls.Add(Me.Label288)
        Me.Panel31.Controls.Add(Me.Label289)
        Me.Panel31.Location = New System.Drawing.Point(3, 3)
        Me.Panel31.Name = "Panel31"
        Me.Panel31.Size = New System.Drawing.Size(479, 133)
        Me.Panel31.TabIndex = 17
        '
        'Label283
        '
        Me.Label283.BackColor = System.Drawing.Color.WhiteSmoke
        Me.Label283.Location = New System.Drawing.Point(350, 9)
        Me.Label283.Name = "Label283"
        Me.Label283.Size = New System.Drawing.Size(93, 16)
        Me.Label283.TabIndex = 0
        Me.Label283.Text = "1.5"
        Me.Label283.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'Label284
        '
        Me.Label284.BackColor = System.Drawing.Color.WhiteSmoke
        Me.Label284.Location = New System.Drawing.Point(350, 34)
        Me.Label284.Name = "Label284"
        Me.Label284.Size = New System.Drawing.Size(93, 16)
        Me.Label284.TabIndex = 1
        Me.Label284.Text = "-0.5"
        Me.Label284.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'Label285
        '
        Me.Label285.Location = New System.Drawing.Point(5, 9)
        Me.Label285.Name = "Label285"
        Me.Label285.Size = New System.Drawing.Size(189, 23)
        Me.Label285.TabIndex = 2
        Me.Label285.Text = "Result 1"
        '
        'Label286
        '
        Me.Label286.BackColor = System.Drawing.Color.WhiteSmoke
        Me.Label286.Location = New System.Drawing.Point(95, 101)
        Me.Label286.Name = "Label286"
        Me.Label286.Size = New System.Drawing.Size(65, 20)
        Me.Label286.TabIndex = 3
        Me.Label286.Text = "mm"
        Me.Label286.TextAlign = System.Drawing.ContentAlignment.TopCenter
        '
        'Label287
        '
        Me.Label287.BackColor = System.Drawing.Color.WhiteSmoke
        Me.Label287.Location = New System.Drawing.Point(288, 9)
        Me.Label287.Name = "Label287"
        Me.Label287.Size = New System.Drawing.Size(56, 16)
        Me.Label287.TabIndex = 26
        Me.Label287.Text = "USL"
        Me.Label287.TextAlign = System.Drawing.ContentAlignment.TopRight
        '
        'Label288
        '
        Me.Label288.BackColor = System.Drawing.Color.WhiteSmoke
        Me.Label288.Location = New System.Drawing.Point(305, 34)
        Me.Label288.Name = "Label288"
        Me.Label288.Size = New System.Drawing.Size(39, 23)
        Me.Label288.TabIndex = 27
        Me.Label288.Text = "LSL"
        '
        'Label289
        '
        Me.Label289.Font = New System.Drawing.Font("Tahoma", 36.0!)
        Me.Label289.ForeColor = System.Drawing.Color.ForestGreen
        Me.Label289.Location = New System.Drawing.Point(21, 34)
        Me.Label289.Name = "Label289"
        Me.Label289.Size = New System.Drawing.Size(224, 55)
        Me.Label289.TabIndex = 28
        Me.Label289.Text = "000.0000"
        Me.Label289.TextAlign = System.Drawing.ContentAlignment.TopCenter
        '
        'SaveFileDialog1
        '
        Me.SaveFileDialog1.CreatePrompt = True
        Me.SaveFileDialog1.DefaultExt = "csv"
        Me.SaveFileDialog1.Filter = "CSV files (*.csv)|*.csv"
        Me.SaveFileDialog1.Title = "Create file for capturing data"
        '
        'OpenFileDialog1
        '
        Me.OpenFileDialog1.AddExtension = False
        Me.OpenFileDialog1.DefaultExt = "csv"
        Me.OpenFileDialog1.Filter = "CSV files (*.csv)|*.csv"
        Me.OpenFileDialog1.Title = "Select file for capturing data"
        '
        'Timer2
        '
        '
        'Timer3
        '
        Me.Timer3.Interval = 300
        '
        'lblReadingSaved
        '
        Me.lblReadingSaved.AutoSize = True
        Me.lblReadingSaved.BackColor = System.Drawing.Color.Lime
        Me.lblReadingSaved.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblReadingSaved.ForeColor = System.Drawing.Color.Black
        Me.lblReadingSaved.Location = New System.Drawing.Point(864, 11)
        Me.lblReadingSaved.Name = "lblReadingSaved"
        Me.lblReadingSaved.Size = New System.Drawing.Size(130, 20)
        Me.lblReadingSaved.TabIndex = 33
        Me.lblReadingSaved.Text = "Reading Saved..."
        Me.lblReadingSaved.Visible = False
        '
        'CustomerOctaGageTableAdapter
        '
        Me.CustomerOctaGageTableAdapter.ClearBeforeFill = True
        '
        'lblFileSel
        '
        Me.lblFileSel.AutoSize = True
        Me.lblFileSel.Location = New System.Drawing.Point(12, 7)
        Me.lblFileSel.Name = "lblFileSel"
        Me.lblFileSel.Size = New System.Drawing.Size(0, 13)
        Me.lblFileSel.TabIndex = 34
        '
        'MeasureOctaGage
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.BackColor = System.Drawing.Color.OldLace
        Me.ClientSize = New System.Drawing.Size(1006, 651)
        Me.Controls.Add(Me.lblFileSel)
        Me.Controls.Add(Me.lblReadingSaved)
        Me.Controls.Add(Me.TabControl1)
        Me.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedToolWindow
        Me.MaximizeBox = False
        Me.MinimizeBox = False
        Me.Name = "MeasureOctaGage"
        Me.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen
        Me.Text = "OctaGage"
        Me.TabControl1.ResumeLayout(False)
        Me.TabPage1.ResumeLayout(False)
        Me.Panel8.ResumeLayout(False)
        Me.Panel8.PerformLayout()
        CType(Me.DataGridView1, System.ComponentModel.ISupportInitialize).EndInit()
        Me.Panel2.ResumeLayout(False)
        Me.Panel2.PerformLayout()
        Me.Panel7.ResumeLayout(False)
        Me.Panel7.PerformLayout()
        Me.Panel4.ResumeLayout(False)
        Me.Panel4.PerformLayout()
        Me.Panel9.ResumeLayout(False)
        Me.Panel9.PerformLayout()
        CType(Me.OctaGageBindingSource, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.VersaGageMonitorDataSet, System.ComponentModel.ISupportInitialize).EndInit()
        Me.Panel5.ResumeLayout(False)
        Me.Panel5.PerformLayout()
        Me.Panel1.ResumeLayout(False)
        Me.Panel1.PerformLayout()
        Me.Panel6.ResumeLayout(False)
        Me.Panel6.PerformLayout()
        Me.Panel3.ResumeLayout(False)
        Me.Panel3.PerformLayout()
        Me.TabPage4.ResumeLayout(False)
        Me.TableLayoutPanel4.ResumeLayout(False)
        Me.Panel20.ResumeLayout(False)
        Me.Panel19.ResumeLayout(False)
        Me.Panel18.ResumeLayout(False)
        Me.Panel17.ResumeLayout(False)
        Me.TabPage5.ResumeLayout(False)
        Me.TableLayoutPanel6.ResumeLayout(False)
        Me.Panel25.ResumeLayout(False)
        Me.Panel26.ResumeLayout(False)
        Me.Panel27.ResumeLayout(False)
        Me.Panel28.ResumeLayout(False)
        Me.TableLayoutPanel5.ResumeLayout(False)
        Me.Panel21.ResumeLayout(False)
        Me.Panel22.ResumeLayout(False)
        Me.Panel23.ResumeLayout(False)
        Me.Panel24.ResumeLayout(False)
        Me.TableLayoutPanel2.ResumeLayout(False)
        Me.Panel29.ResumeLayout(False)
        Me.Panel30.ResumeLayout(False)
        Me.Panel31.ResumeLayout(False)
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub
    Friend WithEvents TabControl1 As System.Windows.Forms.TabControl
    Friend WithEvents TabPage1 As System.Windows.Forms.TabPage
    Friend WithEvents TabPage4 As System.Windows.Forms.TabPage
    Friend WithEvents TableLayoutPanel4 As System.Windows.Forms.TableLayoutPanel
    Friend WithEvents RunChart1 As VersaGageMonitor.RunChart
    Friend WithEvents Panel5 As System.Windows.Forms.Panel
    Friend WithEvents Label5 As System.Windows.Forms.Label
    Friend WithEvents Label1 As System.Windows.Forms.Label
    Friend WithEvents Panel8 As System.Windows.Forms.Panel
    Friend WithEvents Label52 As System.Windows.Forms.Label
    Friend WithEvents Label56 As System.Windows.Forms.Label
    Friend WithEvents Panel7 As System.Windows.Forms.Panel
    Friend WithEvents Label45 As System.Windows.Forms.Label
    Friend WithEvents Label49 As System.Windows.Forms.Label
    Friend WithEvents Panel2 As System.Windows.Forms.Panel
    Friend WithEvents Label17 As System.Windows.Forms.Label
    Friend WithEvents Label21 As System.Windows.Forms.Label
    Friend WithEvents Panel1 As System.Windows.Forms.Panel
    Friend WithEvents Label10 As System.Windows.Forms.Label
    Friend WithEvents Label14 As System.Windows.Forms.Label
    Friend WithEvents Panel4 As System.Windows.Forms.Panel
    Friend WithEvents Label31 As System.Windows.Forms.Label
    Friend WithEvents Label35 As System.Windows.Forms.Label
    Friend WithEvents Panel3 As System.Windows.Forms.Panel
    Friend WithEvents Label24 As System.Windows.Forms.Label
    Friend WithEvents Label28 As System.Windows.Forms.Label
    Friend WithEvents Panel6 As System.Windows.Forms.Panel
    Friend WithEvents Label38 As System.Windows.Forms.Label
    Friend WithEvents Label42 As System.Windows.Forms.Label
    Friend WithEvents Panel17 As System.Windows.Forms.Panel
    Friend WithEvents Label105 As System.Windows.Forms.Label
    Friend WithEvents Label124 As System.Windows.Forms.Label
    Friend WithEvents Label125 As System.Windows.Forms.Label
    Friend WithEvents Label120 As System.Windows.Forms.Label
    Friend WithEvents Label121 As System.Windows.Forms.Label
    Friend WithEvents Label122 As System.Windows.Forms.Label
    Friend WithEvents Label123 As System.Windows.Forms.Label
    Friend WithEvents Label114 As System.Windows.Forms.Label
    Friend WithEvents Label115 As System.Windows.Forms.Label
    Friend WithEvents Label117 As System.Windows.Forms.Label
    Friend WithEvents Label118 As System.Windows.Forms.Label
    Friend WithEvents Label119 As System.Windows.Forms.Label
    Friend WithEvents Panel20 As System.Windows.Forms.Panel
    Friend WithEvents Label152 As System.Windows.Forms.Label
    Friend WithEvents Label154 As System.Windows.Forms.Label
    Friend WithEvents Label155 As System.Windows.Forms.Label
    Friend WithEvents Label158 As System.Windows.Forms.Label
    Friend WithEvents Label159 As System.Windows.Forms.Label
    Friend WithEvents Label163 As System.Windows.Forms.Label
    Friend WithEvents Label164 As System.Windows.Forms.Label
    Friend WithEvents RunChart4 As VersaGageMonitor.RunChart
    Friend WithEvents Panel19 As System.Windows.Forms.Panel
    Friend WithEvents Label139 As System.Windows.Forms.Label
    Friend WithEvents Label141 As System.Windows.Forms.Label
    Friend WithEvents Label142 As System.Windows.Forms.Label
    Friend WithEvents Label145 As System.Windows.Forms.Label
    Friend WithEvents Label146 As System.Windows.Forms.Label
    Friend WithEvents Label150 As System.Windows.Forms.Label
    Friend WithEvents Label151 As System.Windows.Forms.Label
    Friend WithEvents RunChart3 As VersaGageMonitor.RunChart
    Friend WithEvents Panel18 As System.Windows.Forms.Panel
    Friend WithEvents Label126 As System.Windows.Forms.Label
    Friend WithEvents Label128 As System.Windows.Forms.Label
    Friend WithEvents Label129 As System.Windows.Forms.Label
    Friend WithEvents Label132 As System.Windows.Forms.Label
    Friend WithEvents Label133 As System.Windows.Forms.Label
    Friend WithEvents Label137 As System.Windows.Forms.Label
    Friend WithEvents Label138 As System.Windows.Forms.Label
    Friend WithEvents RunChart2 As VersaGageMonitor.RunChart
    Friend WithEvents TabPage5 As System.Windows.Forms.TabPage
    Friend WithEvents TableLayoutPanel5 As System.Windows.Forms.TableLayoutPanel
    Friend WithEvents Panel21 As System.Windows.Forms.Panel
    Friend WithEvents Label165 As System.Windows.Forms.Label
    Friend WithEvents Label166 As System.Windows.Forms.Label
    Friend WithEvents Label167 As System.Windows.Forms.Label
    Friend WithEvents Label168 As System.Windows.Forms.Label
    Friend WithEvents Label169 As System.Windows.Forms.Label
    Friend WithEvents Label170 As System.Windows.Forms.Label
    Friend WithEvents Label171 As System.Windows.Forms.Label
    Friend WithEvents Label172 As System.Windows.Forms.Label
    Friend WithEvents Label173 As System.Windows.Forms.Label
    Friend WithEvents Label174 As System.Windows.Forms.Label
    Friend WithEvents Label175 As System.Windows.Forms.Label
    Friend WithEvents Label176 As System.Windows.Forms.Label
    Friend WithEvents Label177 As System.Windows.Forms.Label
    'Friend WithEvents RunChart5 As VersaGageMonitor.RunChart
    Friend WithEvents Panel22 As System.Windows.Forms.Panel
    Friend WithEvents Label178 As System.Windows.Forms.Label
    Friend WithEvents Label179 As System.Windows.Forms.Label
    Friend WithEvents Label180 As System.Windows.Forms.Label
    Friend WithEvents Label181 As System.Windows.Forms.Label
    Friend WithEvents Label182 As System.Windows.Forms.Label
    Friend WithEvents Label183 As System.Windows.Forms.Label
    Friend WithEvents Label184 As System.Windows.Forms.Label
    Friend WithEvents Label185 As System.Windows.Forms.Label
    Friend WithEvents Label186 As System.Windows.Forms.Label
    Friend WithEvents Label187 As System.Windows.Forms.Label
    Friend WithEvents Label188 As System.Windows.Forms.Label
    Friend WithEvents Label189 As System.Windows.Forms.Label
    Friend WithEvents Label190 As System.Windows.Forms.Label
    'Friend WithEvents RunChart6 As VersaGageMonitor.RunChart
    Friend WithEvents Panel23 As System.Windows.Forms.Panel
    Friend WithEvents Label191 As System.Windows.Forms.Label
    Friend WithEvents Label192 As System.Windows.Forms.Label
    Friend WithEvents Label193 As System.Windows.Forms.Label
    Friend WithEvents Label194 As System.Windows.Forms.Label
    Friend WithEvents Label195 As System.Windows.Forms.Label
    Friend WithEvents Label196 As System.Windows.Forms.Label
    Friend WithEvents Label197 As System.Windows.Forms.Label
    Friend WithEvents Label198 As System.Windows.Forms.Label
    Friend WithEvents Label199 As System.Windows.Forms.Label
    Friend WithEvents Label200 As System.Windows.Forms.Label
    Friend WithEvents Label201 As System.Windows.Forms.Label
    Friend WithEvents Label202 As System.Windows.Forms.Label
    Friend WithEvents Label203 As System.Windows.Forms.Label
    'Friend WithEvents RunChart7 As VersaGageMonitor.RunChart
    Friend WithEvents Panel24 As System.Windows.Forms.Panel
    Friend WithEvents Label204 As System.Windows.Forms.Label
    Friend WithEvents Label205 As System.Windows.Forms.Label
    Friend WithEvents Label206 As System.Windows.Forms.Label
    Friend WithEvents Label207 As System.Windows.Forms.Label
    Friend WithEvents Label208 As System.Windows.Forms.Label
    Friend WithEvents Label209 As System.Windows.Forms.Label
    Friend WithEvents Label210 As System.Windows.Forms.Label
    Friend WithEvents Label211 As System.Windows.Forms.Label
    Friend WithEvents Label212 As System.Windows.Forms.Label
    Friend WithEvents Label213 As System.Windows.Forms.Label
    Friend WithEvents Label214 As System.Windows.Forms.Label
    Friend WithEvents Label215 As System.Windows.Forms.Label
    Friend WithEvents Label216 As System.Windows.Forms.Label
    'Friend WithEvents RunChart8 As VersaGageMonitor.RunChart
    Friend WithEvents TableLayoutPanel6 As System.Windows.Forms.TableLayoutPanel
    Friend WithEvents Panel25 As System.Windows.Forms.Panel
    Friend WithEvents Label217 As System.Windows.Forms.Label
    Friend WithEvents Label219 As System.Windows.Forms.Label
    Friend WithEvents Label220 As System.Windows.Forms.Label
    Friend WithEvents Label223 As System.Windows.Forms.Label
    Friend WithEvents Label224 As System.Windows.Forms.Label
    Friend WithEvents Label228 As System.Windows.Forms.Label
    Friend WithEvents Label229 As System.Windows.Forms.Label
    Friend WithEvents RunChart9 As VersaGageMonitor.RunChart
    Friend WithEvents Panel26 As System.Windows.Forms.Panel
    Friend WithEvents Label230 As System.Windows.Forms.Label
    Friend WithEvents Label232 As System.Windows.Forms.Label
    Friend WithEvents Label233 As System.Windows.Forms.Label
    Friend WithEvents Label236 As System.Windows.Forms.Label
    Friend WithEvents Label237 As System.Windows.Forms.Label
    Friend WithEvents Label241 As System.Windows.Forms.Label
    Friend WithEvents Label242 As System.Windows.Forms.Label
    Friend WithEvents RunChart10 As VersaGageMonitor.RunChart
    Friend WithEvents Panel27 As System.Windows.Forms.Panel
    Friend WithEvents Label243 As System.Windows.Forms.Label
    Friend WithEvents Label245 As System.Windows.Forms.Label
    Friend WithEvents Label246 As System.Windows.Forms.Label
    Friend WithEvents Label249 As System.Windows.Forms.Label
    Friend WithEvents Label250 As System.Windows.Forms.Label
    Friend WithEvents Label254 As System.Windows.Forms.Label
    Friend WithEvents Label255 As System.Windows.Forms.Label
    Friend WithEvents RunChart11 As VersaGageMonitor.RunChart
    Friend WithEvents Panel28 As System.Windows.Forms.Panel
    Friend WithEvents Label256 As System.Windows.Forms.Label
    Friend WithEvents Label258 As System.Windows.Forms.Label
    Friend WithEvents Label259 As System.Windows.Forms.Label
    Friend WithEvents Label262 As System.Windows.Forms.Label
    Friend WithEvents Label263 As System.Windows.Forms.Label
    Friend WithEvents Label267 As System.Windows.Forms.Label
    Friend WithEvents Label268 As System.Windows.Forms.Label
    Friend WithEvents RunChart12 As VersaGageMonitor.RunChart
    Friend WithEvents TableLayoutPanel2 As System.Windows.Forms.TableLayoutPanel
    Friend WithEvents Panel29 As System.Windows.Forms.Panel
    Friend WithEvents Label269 As System.Windows.Forms.Label
    Friend WithEvents Label270 As System.Windows.Forms.Label
    Friend WithEvents Label271 As System.Windows.Forms.Label
    Friend WithEvents Label272 As System.Windows.Forms.Label
    Friend WithEvents Label273 As System.Windows.Forms.Label
    Friend WithEvents Label274 As System.Windows.Forms.Label
    Friend WithEvents Label275 As System.Windows.Forms.Label
    Friend WithEvents Panel30 As System.Windows.Forms.Panel
    Friend WithEvents Label276 As System.Windows.Forms.Label
    Friend WithEvents Label277 As System.Windows.Forms.Label
    Friend WithEvents Label278 As System.Windows.Forms.Label
    Friend WithEvents Label279 As System.Windows.Forms.Label
    Friend WithEvents Label280 As System.Windows.Forms.Label
    Friend WithEvents Label281 As System.Windows.Forms.Label
    Friend WithEvents Label282 As System.Windows.Forms.Label
    Friend WithEvents Panel31 As System.Windows.Forms.Panel
    Friend WithEvents Label283 As System.Windows.Forms.Label
    Friend WithEvents Label284 As System.Windows.Forms.Label
    Friend WithEvents Label285 As System.Windows.Forms.Label
    Friend WithEvents Label286 As System.Windows.Forms.Label
    Friend WithEvents Label287 As System.Windows.Forms.Label
    Friend WithEvents Label288 As System.Windows.Forms.Label
    Friend WithEvents Label289 As System.Windows.Forms.Label
    Friend WithEvents Label153 As System.Windows.Forms.Label
    Friend WithEvents Label156 As System.Windows.Forms.Label
    Friend WithEvents Label157 As System.Windows.Forms.Label
    Friend WithEvents Label161 As System.Windows.Forms.Label
    Friend WithEvents Label162 As System.Windows.Forms.Label
    Friend WithEvents Label140 As System.Windows.Forms.Label
    Friend WithEvents Label143 As System.Windows.Forms.Label
    Friend WithEvents Label144 As System.Windows.Forms.Label
    Friend WithEvents Label148 As System.Windows.Forms.Label
    Friend WithEvents Label149 As System.Windows.Forms.Label
    Friend WithEvents Label127 As System.Windows.Forms.Label
    Friend WithEvents Label130 As System.Windows.Forms.Label
    Friend WithEvents Label131 As System.Windows.Forms.Label
    Friend WithEvents Label135 As System.Windows.Forms.Label
    Friend WithEvents Label136 As System.Windows.Forms.Label
    Friend WithEvents Label257 As System.Windows.Forms.Label
    Friend WithEvents Label260 As System.Windows.Forms.Label
    Friend WithEvents Label261 As System.Windows.Forms.Label
    Friend WithEvents Label265 As System.Windows.Forms.Label
    Friend WithEvents Label266 As System.Windows.Forms.Label
    Friend WithEvents Label244 As System.Windows.Forms.Label
    Friend WithEvents Label247 As System.Windows.Forms.Label
    Friend WithEvents Label248 As System.Windows.Forms.Label
    Friend WithEvents Label252 As System.Windows.Forms.Label
    Friend WithEvents Label253 As System.Windows.Forms.Label
    Friend WithEvents Label231 As System.Windows.Forms.Label
    Friend WithEvents Label234 As System.Windows.Forms.Label
    Friend WithEvents Label235 As System.Windows.Forms.Label
    Friend WithEvents Label239 As System.Windows.Forms.Label
    Friend WithEvents Label240 As System.Windows.Forms.Label
    Friend WithEvents Label218 As System.Windows.Forms.Label
    Friend WithEvents Label221 As System.Windows.Forms.Label
    Friend WithEvents Label222 As System.Windows.Forms.Label
    Friend WithEvents Label226 As System.Windows.Forms.Label
    Friend WithEvents Label227 As System.Windows.Forms.Label
    Friend WithEvents SaveFileDialog1 As System.Windows.Forms.SaveFileDialog
    Friend WithEvents OpenFileDialog1 As System.Windows.Forms.OpenFileDialog
    Friend WithEvents Timer2 As System.Windows.Forms.Timer
    Friend WithEvents Timer3 As System.Windows.Forms.Timer
    Friend WithEvents lblReadingSaved As System.Windows.Forms.Label
    Friend WithEvents VersaGageMonitorDataSet As VersaGageMonitor.VersaGageMonitorDataSet
    Friend WithEvents CustomerOctaGageTableAdapter As VersaGageMonitor.VersaGageMonitorDataSetTableAdapters.CustomerOctaGageTableAdapter
    Friend WithEvents OctaGageBindingSource As System.Windows.Forms.BindingSource
    Friend WithEvents Panel9 As System.Windows.Forms.Panel
    Friend WithEvents DataGridView1 As System.Windows.Forms.DataGridView
    Friend WithEvents Button1 As System.Windows.Forms.Button
    Friend WithEvents btnSelectFile As System.Windows.Forms.Button
    Friend WithEvents btnStart As System.Windows.Forms.Button
    Friend WithEvents Label6 As System.Windows.Forms.Label
    Friend WithEvents Label7 As System.Windows.Forms.Label
    Friend WithEvents Label8 As System.Windows.Forms.Label
    Friend WithEvents Label9 As System.Windows.Forms.Label
    Friend WithEvents cmbPart As System.Windows.Forms.ComboBox
    Friend WithEvents Label2 As System.Windows.Forms.Label
    Friend WithEvents btnResetCounter As System.Windows.Forms.Button
    Friend WithEvents lblCounter As System.Windows.Forms.Label
    Friend WithEvents Label12 As System.Windows.Forms.Label
    Friend WithEvents Column1 As System.Windows.Forms.DataGridViewTextBoxColumn
    Friend WithEvents Column2 As System.Windows.Forms.DataGridViewTextBoxColumn
    Friend WithEvents Column3 As System.Windows.Forms.DataGridViewTextBoxColumn
    Friend WithEvents Column4 As System.Windows.Forms.DataGridViewTextBoxColumn
    Friend WithEvents Column5 As System.Windows.Forms.DataGridViewTextBoxColumn
    Friend WithEvents Column6 As System.Windows.Forms.DataGridViewTextBoxColumn
    Friend WithEvents Column7 As System.Windows.Forms.DataGridViewTextBoxColumn
    Friend WithEvents Column8 As System.Windows.Forms.DataGridViewTextBoxColumn
    Friend WithEvents Column9 As System.Windows.Forms.DataGridViewTextBoxColumn
    Friend WithEvents Column10 As System.Windows.Forms.DataGridViewTextBoxColumn
    Friend WithEvents lblFileSel As System.Windows.Forms.Label
End Class
